# Q14 – Availability vs Consistency in Cassandra

Replication factor **RF = 3** (every row is stored on all 3 nodes).
Quorum = floor(RF/2) + 1 = **2 replicas**.

## 0. Start the 3-node cluster (start one by one, wait ~90 s each)
```bash
docker compose up -d cass1   # wait
docker compose up -d cass2   # wait
docker compose up -d cass3   # wait
docker exec cass1 nodetool status          # 3 nodes UN
docker exec -i cass1 cqlsh < setup.cql
```

## 1. All nodes up – every level works
```bash
docker exec -i cass1 cqlsh <<'CQL'
USE ConsistencyDemo;
CONSISTENCY ONE;
INSERT INTO accounts (acc_id, owner, balance) VALUES (1, 'Amit', 1000);
CONSISTENCY QUORUM;
INSERT INTO accounts (acc_id, owner, balance) VALUES (2, 'Priya', 2000);
CONSISTENCY ALL;
INSERT INTO accounts (acc_id, owner, balance) VALUES (3, 'Rahul', 3000);
SELECT * FROM accounts;
CONSISTENCY QUORUM;
SELECT * FROM accounts;
CONSISTENCY ONE;
SELECT * FROM accounts;
CQL
```
✅ ONE, QUORUM and ALL all succeed.

## 2. Stop ONE node (1 of 3 down)
```bash
docker stop cass3
docker exec -i cass1 cqlsh <<'CQL'
USE ConsistencyDemo;
CONSISTENCY ALL;
INSERT INTO accounts (acc_id, owner, balance) VALUES (4, 'Neha', 4000);
CONSISTENCY QUORUM;
INSERT INTO accounts (acc_id, owner, balance) VALUES (4, 'Neha', 4000);
CONSISTENCY ONE;
INSERT INTO accounts (acc_id, owner, balance) VALUES (5, 'Karan', 5000);
CQL
```
| Level | Result | Why |
|---|---|---|
| ALL | ❌ `Unavailable – Cannot achieve consistency level ALL` | needs 3 replicas, only 2 alive |
| QUORUM | ✅ works | needs 2, 2 alive |
| ONE | ✅ works | needs 1 |

## 3. Stop a SECOND node (only 1 alive)
```bash
docker stop cass2
docker exec -i cass1 cqlsh <<'CQL'
USE ConsistencyDemo;
CONSISTENCY QUORUM;
SELECT * FROM accounts;
CONSISTENCY ONE;
SELECT * FROM accounts;
CQL
```
| Level | Result |
|---|---|
| QUORUM | ❌ Unavailable (needs 2, only 1 alive) |
| ONE | ✅ works – maximum availability |

## 4. Bring nodes back – Cassandra repairs the missed writes
```bash
docker start cass2 cass3          # wait for UN
docker exec cass1 nodetool status
docker exec cass3 nodetool repair consistencydemo
docker exec -i cass3 cqlsh -e "CONSISTENCY ONE; SELECT * FROM consistencydemo.accounts;"
```
Rows 4 and 5 (written while cass3 was down) are now on cass3 too – via **hinted handoff** / **read repair** / `nodetool repair`.

## Observations (write in your report)
- **ONE:** fastest, most available, but may return stale data.
- **QUORUM:** balance – if writes and reads both use QUORUM, `R + W > RF` (2 + 2 > 3) gives **strong consistency**, and it tolerates 1 failed node.
- **ALL:** strongest consistency but lowest availability – fails if any replica is down.
- This is the CAP trade-off: Cassandra lets you tune **C vs A per query**.
