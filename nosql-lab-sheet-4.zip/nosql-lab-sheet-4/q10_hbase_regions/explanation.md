# Regions and RegionServers

```
              ZooKeeper  (cluster coordination, failure detection)
                   |
               HMaster   (assigns regions, balances load, handles failover)
        ____________|______________
       |            |              |
 RegionServer1  RegionServer2  RegionServer3
  [R1] [R4]       [R2]            [R3]
       \___________|______________/
               HDFS  (data files are replicated, usually 3 copies)
```

- **Region** = a contiguous range of row keys of one table (e.g. `00000000 – 3fffffff`).
- When a region grows beyond a size limit it **splits automatically** into two.
- Each region is served by exactly **one RegionServer** at a time; one server hosts many regions.

**Scalability:** more data → more regions → HMaster assigns them to more RegionServers. Reads/writes for different key ranges are handled in parallel by different servers.

**Availability:** HBase stores its files (HFiles) and the WAL in **HDFS**, which keeps replicas. If a RegionServer dies, ZooKeeper notices, HMaster **reassigns its regions** to other servers, and the WAL is replayed so no committed writes are lost. Clients re-locate the region via the `hbase:meta` table.

*Note:* with the Docker image you only have one RegionServer, so all 4 regions live on the same server. On a real cluster `list_regions` shows different server names.
