# BCA305P – NoSQL Database Design: Lab Sheet 4 (HBase & Cassandra)

**Name:** ______________  **Roll No:** ______________

| Q | Topic | Folder |
|---|---|---|
| 1 | Install HBase, Student table | `q01_hbase_install_student` |
| 2 | Employee CRUD (HBase) | `q02_hbase_employee_crud` |
| 3 | Event logging (HBase) | `q03_hbase_event_logging` |
| 4 | CMS (HBase) | `q04_hbase_cms` |
| 5 | Blogging platform (HBase) | `q05_hbase_blog` |
| 6 | Column-family data model | `q06_hbase_column_family_model` |
| 7 | WebsiteCounter (incr) | `q07_hbase_counters` |
| 8 | Sessions with TTL | `q08_hbase_ttl_sessions` |
| 9 | Row-key design / scaling | `q09_hbase_rowkey_design` |
| 10 | Regions & RegionServers | `q10_hbase_regions` |
| 11 | Install Cassandra, Students | `q11_cassandra_install_students` |
| 12 | Employees CRUD (Cassandra) | `q12_cassandra_employees_crud` |
| 13 | Event logging (Cassandra) | `q13_cassandra_event_logging` |
| 14 | Consistency levels ONE/QUORUM/ALL | `q14_cassandra_consistency` |
| 15 | Column-oriented app (Blog on Cassandra) | `q15_column_oriented_app` |

## Run HBase scripts (Q1–Q10)
```bash
docker run -d --name hbase -p 16010:16010 -p 2181:2181 harisekhon/hbase
docker cp q02_hbase_employee_crud/employee_crud.hbase hbase:/tmp/s.hbase
docker exec -it hbase hbase shell /tmp/s.hbase
```
Tip: for screenshots, open `docker exec -it hbase hbase shell` and paste the commands a few at a time.
To re-run a script, first `disable '<table>'` then `drop '<table>'`.

## Run Cassandra scripts (Q11–Q13, Q15)
```bash
docker run -d --name cass -p 9042:9042 cassandra:4.1      # wait ~90 s
docker exec -i cass cqlsh < q11_cassandra_install_students/students.cql
```
Q14 needs a 3-node cluster – follow `q14_cassandra_consistency/steps.md`.

## Upload to GitHub
```bash
git init && git add . && git commit -m "Add NoSQL Lab Sheet 4"
git branch -M main
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```
