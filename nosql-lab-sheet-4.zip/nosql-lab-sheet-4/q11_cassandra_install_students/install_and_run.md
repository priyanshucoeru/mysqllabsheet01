# Q11 – Install & configure Cassandra

## Option A – Docker (recommended)
```bash
docker run -d --name cass -p 9042:9042 cassandra:4.1
# wait ~60-90 seconds, then check:
docker exec cass nodetool status        # should show "UN" (Up/Normal)
docker exec -it cass cqlsh
```

## Option B – Local install (Linux/WSL)
```bash
sudo apt install -y openjdk-11-jre-headless python3
echo "deb [signed-by=/etc/apt/keyrings/apache-cassandra.asc] https://debian.cassandra.apache.org 41x main" | sudo tee /etc/apt/sources.list.d/cassandra.sources.list
sudo curl -o /etc/apt/keyrings/apache-cassandra.asc https://downloads.apache.org/cassandra/KEYS
sudo apt update && sudo apt install -y cassandra
sudo systemctl start cassandra && nodetool status
cqlsh
```

## Run the script
```bash
docker exec -i cass cqlsh < students.cql
```

## Replication factor – why 1 here?
A single node can hold only 1 replica, so `replication_factor = 1`. On a 3-node cluster use 3 (see Q14).
