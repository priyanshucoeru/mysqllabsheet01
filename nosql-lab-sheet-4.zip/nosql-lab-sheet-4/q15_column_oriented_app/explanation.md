# Q15 – How Cassandra handles the key database concerns (Blogging Platform)

| Concern | How Cassandra handles it |
|---|---|
| **Data model** | Wide-column: `keyspace → table → partition (partition key) → rows sorted by clustering key → columns`. Tables are designed **per query** and data is **denormalised** (`blogs_by_author`, `blogs_by_id`) – no joins. |
| **Consistency** | **Tunable** per query: `ONE`, `QUORUM`, `ALL`, `LOCAL_QUORUM`… With `R + W > RF` (e.g. QUORUM + QUORUM) reads see the latest write. Default is eventual consistency; replicas are healed by hinted handoff, read repair and `nodetool repair`. |
| **Availability** | Peer-to-peer ring, **no master**. Every row is stored on `RF` nodes; the cluster keeps serving reads/writes while nodes are down (AP side of CAP). |
| **Transactions** | **No multi-table ACID transactions.** Available: single-partition writes are atomic & isolated; **logged batches** for atomic multi-table writes (all-or-nothing, not isolated); **lightweight transactions** (`IF NOT EXISTS`, `IF col = x`) using Paxos for compare-and-set. |
| **Query features** | CQL (SQL-like) but: query must supply the partition key; range filters only on clustering columns; no joins / GROUP BY across partitions; secondary indexes for low-cardinality columns; collections (`set`, `list`, `map`); counters; TTL; `ALLOW FILTERING` (avoid on big tables). |
| **Scaling** | **Linear horizontal scaling:** add nodes → the token ring rebalances automatically (vnodes), throughput grows with the number of nodes. Writes are very fast (append to commit log + memtable, flushed to SSTables). Multi-datacenter replication supported. |

## Why Cassandra for a blog?
Blogs are read-heavy and need to stay available; denormalised tables give fast reads, and comment / view counts scale out easily.

## Limitations
No joins, limited ad-hoc queries, data duplicated across tables (you must keep copies in sync), eventual consistency by default.
