# How HBase stores columns inside column families

**Logical model:** `Table → Row (row key) → Column Family → Qualifier (column) → Timestamp → Value`.
Every cell is addressed by `(rowkey, family:qualifier, timestamp)`.

**What the implementation shows**
1. Column families (`personal`, `contact`, `activity`) are fixed when the table is created (`describe` shows them).
2. **Qualifiers are not fixed.** Row `u1` has `personal:age`, row `u2` has `contact:twitter`, row `u3` has only `activity`. Nothing is stored for columns a row doesn't have → HBase is **sparse** (no NULLs).
3. `scan` returns **one cell per line** – the data is physically stored as key-value cells, sorted by row key, then family, qualifier, and newest timestamp first.
4. Physically, **each column family has its own store** (MemStore in RAM + HFiles on HDFS). `scan ... {COLUMNS=>['contact']}` reads only the `contact` files – columns that are queried together should be placed in the same family.
5. Multiple versions: after changing `personal:city` twice, `get ... VERSIONS=>3` returns both values with their timestamps.

**Design rule:** keep few column families (1–3), group columns that are accessed together, use short names.
