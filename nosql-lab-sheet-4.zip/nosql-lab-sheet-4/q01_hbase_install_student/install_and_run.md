# Q1 – Install & configure HBase, create Student table

## Option A – Docker (quickest, works on Windows/Mac/Linux)
```bash
docker run -d --name hbase -p 16010:16010 -p 2181:2181 harisekhon/hbase
docker exec -it hbase hbase shell
```
HBase Master web UI: http://localhost:16010

## Option B – Local install (Linux/WSL)
```bash
sudo apt install -y openjdk-11-jdk
wget https://dlcdn.apache.org/hbase/2.5.10/hbase-2.5.10-bin.tar.gz   # use the latest 2.5.x from hbase.apache.org
tar -xzf hbase-2.5.10-bin.tar.gz && cd hbase-2.5.10
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
# conf/hbase-site.xml (standalone mode):
#   <property><name>hbase.rootdir</name><value>file:///home/<user>/hbase-data</value></property>
bin/start-hbase.sh
bin/hbase shell
```
Verify with `status` and `version` inside the shell.

## Run the script
```bash
# Docker:
docker cp student.hbase hbase:/student.hbase && docker exec -it hbase hbase shell /student.hbase
# Local:
bin/hbase shell student.hbase
```
(or paste commands one by one into the shell and take screenshots)
