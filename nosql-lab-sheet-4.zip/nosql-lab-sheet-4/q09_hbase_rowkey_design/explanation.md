# Row-key design and horizontal scaling

HBase keeps rows **sorted by row key** and splits the table into **regions** (contiguous key ranges). Each region is served by one RegionServer. So the row key decides how data and load are spread.

| Strategy | Example | Effect |
|---|---|---|
| Sequential | `order-000001`, `order-000002` | ❌ All new writes hit the last region → hotspot, no scaling |
| **Salting** | `02_amit_8209...` | ✅ Writes spread across `N` regions evenly |
| Hashing | `md5(user)` | ✅ Even, but range scans are lost |
| Reverse timestamp | `user_(MAX - ts)` | ✅ Newest first for each user |
| Composite | `salt_user_revts` | ✅ Even writes + efficient per-user range scans |

**Our key:** `<2-digit salt>_<customer>_<reverse timestamp>`
- salt spreads customers across 4 pre-split regions → 4 RegionServers can take writes in parallel
- customer part keeps one customer's orders together → single range scan
- reverse timestamp returns the latest order first

When data grows, add RegionServers: regions split automatically and the balancer moves them to the new servers → **horizontal scaling** with no application change.
