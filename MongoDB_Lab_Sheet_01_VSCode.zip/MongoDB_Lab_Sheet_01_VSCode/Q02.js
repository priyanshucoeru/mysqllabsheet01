// Q2. Create Students, Faculty, and Courses collections.
import { withDb, ensureCollection } from "./db.js";

await withDb(async db => {
    await ensureCollection(db, "Students");
    await ensureCollection(db, "Faculty");
    await ensureCollection(db, "Courses");
    console.log("Collections:", (await db.listCollections().toArray()).map(c => c.name));
});
