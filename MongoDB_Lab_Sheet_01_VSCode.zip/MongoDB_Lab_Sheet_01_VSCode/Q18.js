// Q18. Create Departments collection and insert sample data.
import { withDb, ensureCollection } from "./db.js";

await withDb(async db => {
    await ensureCollection(db, "Departments");
    const records = [
        { DeptID: 1, DeptName: "Computer Science", HOD: "Dr. Sharma" },
        { DeptID: 2, DeptName: "IT", HOD: "Dr. Verma" },
        { DeptID: 3, DeptName: "Management", HOD: "Dr. Gupta" }
    ];
    for (const record of records) {
        await db.collection("Departments").updateOne(
            { DeptID: record.DeptID }, { $set: record }, { upsert: true }
        );
    }
    console.log(await db.collection("Departments").find({}).toArray());
});
