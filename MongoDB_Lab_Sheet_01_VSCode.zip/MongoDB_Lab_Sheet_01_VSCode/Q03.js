// Q3. Insert a single student document.
import { withDb } from "./db.js";

await withDb(async db => {
    const students = db.collection("Students");
    await students.updateOne(
        { RollNo: 101 },
        { $set: { RollNo: 101, Name: "Rahul", Department: "Computer Science", Semester: 5, CGPA: 8.5 } },
        { upsert: true }
    );
    console.log("Inserted or refreshed student:", await students.findOne({ RollNo: 101 }));
});
