// Q9. Update one student's department.
import { withDb } from "./db.js";

await withDb(async db => {
    const result = await db.collection("Students").updateOne(
        { RollNo: 101 },
        { $set: { Department: "IT" } }
    );
    console.log(result);
});
