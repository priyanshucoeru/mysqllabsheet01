// Q12. Add an Email field to all student documents.
import { withDb } from "./db.js";

await withDb(async db => {
    const result = await db.collection("Students").updateMany(
        {},
        { $set: { Email: "student@example.com" } }
    );
    console.log(result);
});
