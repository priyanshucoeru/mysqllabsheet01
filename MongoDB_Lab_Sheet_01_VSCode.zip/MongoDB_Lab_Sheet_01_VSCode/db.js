import { MongoClient } from "mongodb";

const uri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017";
const client = new MongoClient(uri);

export async function withDb(action) {
    try {
        await client.connect();
        const db = client.db("StudentDB");
        await action(db, client);
    } catch (error) {
        console.error("Error:", error.message);
        console.error("Make sure MongoDB Server is running and the connection URI is correct.");
        process.exitCode = 1;
    } finally {
        await client.close();
    }
}

export async function ensureCollection(db, name) {
    const exists = await db.listCollections({ name }).hasNext();
    if (!exists) {
        await db.createCollection(name);
        console.log(`Collection '${name}' created.`);
    } else {
        console.log(`Collection '${name}' already exists.`);
    }
}
