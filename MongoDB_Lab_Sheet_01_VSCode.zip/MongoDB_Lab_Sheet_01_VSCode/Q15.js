// Q15. Delete all students in the IT department.
import { withDb } from "./db.js";

await withDb(async db => {
    const result = await db.collection("Students").deleteMany({ Department: "IT" });
    console.log(result);
});
