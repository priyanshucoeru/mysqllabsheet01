// Q20. Drop StudentDB database and confirm.
import { withDb } from "./db.js";

await withDb(async (db, client) => {
    const result = await db.dropDatabase();
    console.log("Drop result:", result);
    const list = await client.db("admin").command({ listDatabases: 1 });
    console.log("StudentDB exists:", list.databases.some(item => item.name === "StudentDB"));
});
