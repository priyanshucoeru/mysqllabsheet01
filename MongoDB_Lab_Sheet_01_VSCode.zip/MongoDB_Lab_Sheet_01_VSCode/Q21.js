// Q21. Recreate StudentDB and insert sample data after deletion.
import { withDb } from "./db.js";

await withDb(async db => {
    const students = db.collection("Students");
    await students.insertMany([
        { RollNo: 201, Name: "Amit", Department: "IT", Semester: 5, CGPA: 8.4 },
        { RollNo: 202, Name: "Riya", Department: "Computer Science", Semester: 5, CGPA: 9.0 }
    ]);
    console.log(await students.find({}).toArray());
});
