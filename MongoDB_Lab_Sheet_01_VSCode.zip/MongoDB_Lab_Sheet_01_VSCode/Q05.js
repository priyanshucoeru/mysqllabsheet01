// Q5. Retrieve all student documents.
import { withDb } from "./db.js";

await withDb(async db => {
    console.log(await db.collection("Students").find({}).toArray());
});
