// Q7. Find students by department.
import { withDb } from "./db.js";

await withDb(async db => {
    console.log(await db.collection("Students").find({ Department: "Computer Science" }).toArray());
});
