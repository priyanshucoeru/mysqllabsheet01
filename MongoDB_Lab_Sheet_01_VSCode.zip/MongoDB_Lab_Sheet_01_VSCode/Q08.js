// Q8. Display only Name and Department (projection).
import { withDb } from "./db.js";

await withDb(async db => {
    console.log(await db.collection("Students")
        .find({}, { projection: { _id: 0, Name: 1, Department: 1 } }).toArray());
});
