// Q16. Count all student documents.
import { withDb } from "./db.js";

await withDb(async db => {
    console.log("Total students:", await db.collection("Students").countDocuments({}));
});
