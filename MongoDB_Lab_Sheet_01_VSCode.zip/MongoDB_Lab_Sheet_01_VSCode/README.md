
# BCA Lab Sheet-01 — MongoDB (VS Code)

This project contains a separate JavaScript file for each of the 25 questions in the NoSQL Database Design lab sheet.

## Requirements
1. Install Node.js (LTS).
2. Install and start MongoDB Community Server locally, or create a MongoDB Atlas cluster.
3. Install Visual Studio Code.

## Setup
Open this folder in VS Code. Open Terminal > New Terminal and run:

```bash
npm install
```

The default connection is `mongodb://127.0.0.1:27017`. Make sure the local MongoDB service is running before executing a file.

For MongoDB Atlas, set the connection string as an environment variable before running:
- Windows PowerShell:
  `$env:MONGODB_URI="your-mongodb-connection-string"`
- macOS/Linux:
  `export MONGODB_URI="your-mongodb-connection-string"`

Do not commit real database passwords or connection strings to GitHub.

## Run a question
Run one file at a time, for example:

```bash
node Q01.js
node Q02.js
node Q03.js
```

Files `Q01.js` through `Q24.js` contain separate runnable examples. `Q25.md` is the lab report text. For Q22 and Q23, also demonstrate the corresponding actions in MongoDB Compass and take your own screenshots.

## Important notes
- Some practicals depend on data created by earlier questions. Run Q02, Q03 and Q04 first for a typical dataset.
- Q20 deletes the entire `StudentDB` database. Run it only when you are ready to remove the lab database.
- Q17 renames `Students` to `StudentDetails`; run Q02 again if you need to recreate `Students`.
- These scripts use upsert in selected insert examples to reduce duplicate-key issues when rerun.
- Actual output may differ because MongoDB generates `_id` values and reports counts based on the current database contents.
