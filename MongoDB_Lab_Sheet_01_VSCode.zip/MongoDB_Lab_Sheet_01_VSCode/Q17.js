// Q17. Rename Students collection to StudentDetails.
import { withDb } from "./db.js";

await withDb(async db => {
    const names = (await db.listCollections().toArray()).map(c => c.name);
    if (names.includes("Students") && !names.includes("StudentDetails")) {
        await db.collection("Students").rename("StudentDetails");
        console.log("Students renamed to StudentDetails.");
    } else if (names.includes("StudentDetails")) {
        console.log("StudentDetails already exists.");
    } else {
        console.log("Students collection does not exist. Run Q2 first.");
    }
    console.log("Collections:", (await db.listCollections().toArray()).map(c => c.name));
});
