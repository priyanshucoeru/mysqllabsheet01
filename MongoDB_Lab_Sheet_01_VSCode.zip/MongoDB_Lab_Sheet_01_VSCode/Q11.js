// Q11. Replace a student's document.
import { withDb } from "./db.js";

await withDb(async db => {
    const result = await db.collection("Students").replaceOne(
        { RollNo: 103 },
        { RollNo: 103, Name: "Priya Sharma", Department: "IT", Semester: 6, CGPA: 9.0 },
        { upsert: true }
    );
    console.log(result);
});
