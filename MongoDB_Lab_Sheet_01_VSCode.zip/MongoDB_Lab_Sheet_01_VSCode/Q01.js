// Q1. Create StudentDB database and verify it.
// MongoDB creates a database physically after data/collection is added.
import { withDb, ensureCollection } from "./db.js";

await withDb(async (db, client) => {
    await ensureCollection(db, "Students");
    const result = await client.db("admin").command({ listDatabases: 1 });
    console.log("Databases:", result.databases.map(item => item.name));
    console.log("StudentDB exists:", result.databases.some(item => item.name === "StudentDB"));
});
