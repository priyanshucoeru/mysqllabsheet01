// Q19. Drop Departments collection and verify.
import { withDb } from "./db.js";

await withDb(async db => {
    const exists = await db.listCollections({ name: "Departments" }).hasNext();
    if (exists) console.log("Collection dropped:", await db.collection("Departments").drop());
    else console.log("Departments collection does not exist.");
    console.log("Collections:", (await db.listCollections().toArray()).map(c => c.name));
});
