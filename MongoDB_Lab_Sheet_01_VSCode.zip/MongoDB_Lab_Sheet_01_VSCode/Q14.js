// Q14. Delete one student by Roll Number.
import { withDb } from "./db.js";

await withDb(async db => {
    const result = await db.collection("Students").deleteOne({ RollNo: 102 });
    console.log(result);
});
