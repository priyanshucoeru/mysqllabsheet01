// Q6. Find one student by Roll Number.
import { withDb } from "./db.js";

await withDb(async db => {
    console.log(await db.collection("Students").findOne({ RollNo: 102 }));
});
