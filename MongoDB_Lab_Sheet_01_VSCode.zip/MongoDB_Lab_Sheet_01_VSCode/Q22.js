// Q22. CRUD demonstration in VS Code. Repeat the same operations in MongoDB Compass.
import { withDb } from "./db.js";

await withDb(async db => {
    const students = db.collection("CompassDemo");
    // Create
    await students.updateOne(
        { RollNo: 301 },
        { $set: { RollNo: 301, Name: "Rohit", Department: "IT", CGPA: 8.3 } },
        { upsert: true }
    );
    console.log("CREATE:", await students.findOne({ RollNo: 301 }));
    // Read
    console.log("READ:", await students.find({}).toArray());
    // Update
    await students.updateOne({ RollNo: 301 }, { $set: { CGPA: 8.8 } });
    console.log("UPDATE:", await students.findOne({ RollNo: 301 }));
    // Delete
    await students.deleteOne({ RollNo: 301 });
    console.log("DELETE verified:", await students.findOne({ RollNo: 301 }));
});
