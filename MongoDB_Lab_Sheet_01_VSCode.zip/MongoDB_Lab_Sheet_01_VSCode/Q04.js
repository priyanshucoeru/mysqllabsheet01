// Q4. Insert multiple student documents.
import { withDb } from "./db.js";

await withDb(async db => {
    const students = db.collection("Students");
    const records = [
        { RollNo: 102, Name: "Aman", Department: "IT", Semester: 5, CGPA: 8.2 },
        { RollNo: 103, Name: "Priya", Department: "Computer Science", Semester: 5, CGPA: 9.1 },
        { RollNo: 104, Name: "Neha", Department: "Management", Semester: 5, CGPA: 7.8 }
    ];
    for (const record of records) {
        await students.updateOne({ RollNo: record.RollNo }, { $set: record }, { upsert: true });
    }
    console.log("Student records added/updated:", records.length);
});
