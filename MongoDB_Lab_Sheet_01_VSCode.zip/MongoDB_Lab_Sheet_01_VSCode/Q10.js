// Q10. Update semester for all students in a department.
import { withDb } from "./db.js";

await withDb(async db => {
    const result = await db.collection("Students").updateMany(
        { Department: "IT" },
        { $set: { Semester: 6 } }
    );
    console.log(result);
});
