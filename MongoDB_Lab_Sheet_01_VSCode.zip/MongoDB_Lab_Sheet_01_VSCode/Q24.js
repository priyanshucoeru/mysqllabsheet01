// Q24. MongoDB CRUD operations; equivalent SQL statements are in the comments below.
import { withDb } from "./db.js";

await withDb(async db => {
    const students = db.collection("SQLComparison");
    // INSERT equivalent
    await students.updateOne(
        { RollNo: 401 },
        { $set: { RollNo: 401, Name: "Aman", Department: "IT" } },
        { upsert: true }
    );
    console.log("INSERT:", await students.findOne({ RollNo: 401 }));

    // SELECT equivalent
    console.log("SELECT:", await students.find({ RollNo: 401 }).toArray());

    // UPDATE equivalent
    await students.updateOne({ RollNo: 401 }, { $set: { Department: "Computer Science" } });
    console.log("UPDATE:", await students.findOne({ RollNo: 401 }));

    // DELETE equivalent
    console.log("DELETE:", await students.deleteOne({ RollNo: 401 }));
});

/*
Equivalent SQL:
INSERT INTO Students (RollNo, Name, Department) VALUES (401, 'Aman', 'IT');
SELECT * FROM Students WHERE RollNo = 401;
UPDATE Students SET Department = 'Computer Science' WHERE RollNo = 401;
DELETE FROM Students WHERE RollNo = 401;

Difference: MongoDB stores BSON documents in collections; SQL databases store rows in tables.
*/
