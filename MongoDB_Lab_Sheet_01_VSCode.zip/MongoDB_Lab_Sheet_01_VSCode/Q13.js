// Q13. Remove the Email field from all student documents.
import { withDb } from "./db.js";

await withDb(async db => {
    const result = await db.collection("Students").updateMany(
        {},
        { $unset: { Email: "" } }
    );
    console.log(result);
});
