// Q23. Demonstrate database and collection management from VS Code.
// In MongoDB Compass, create/open StudentDB and use the Collections and Documents tabs.
import { withDb, ensureCollection } from "./db.js";

await withDb(async db => {
    await ensureCollection(db, "Demo");
    await db.collection("Demo").updateOne(
        { Name: "Rahul" },
        { $set: { Name: "Rahul", Course: "BCA" } },
        { upsert: true }
    );
    console.log("Database:", db.databaseName);
    console.log("Collections:", (await db.listCollections().toArray()).map(c => c.name));
    console.log("Demo documents:", await db.collection("Demo").find({}).toArray());
});
