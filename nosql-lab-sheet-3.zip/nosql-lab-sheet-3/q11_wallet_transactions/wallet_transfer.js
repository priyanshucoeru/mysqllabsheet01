// Transactions require a replica set (standalone mongod does NOT support them).
// Setup with Docker:
//   docker compose up -d
//   docker exec mongo-rs mongosh --eval 'rs.initiate({_id:"rs0",members:[{_id:0,host:"localhost:27017"}]})'
// Then run:  mongosh wallet_transfer.js
use("WalletDB");
db.wallets.drop();
db.createCollection("wallets");   // collection must exist before using it in a transaction

db.wallets.insertMany([
  { user: "Amit",  balance: 5000 },
  { user: "Priya", balance: 2000 }
]);

function transfer(from, to, amount) {
  const session = db.getMongo().startSession();
  const wallets = session.getDatabase("WalletDB").wallets;
  session.startTransaction({ readConcern: { level: "snapshot" }, writeConcern: { w: "majority" } });
  try {
    const sender = wallets.findOne({ user: from });
    if (!sender || sender.balance < amount) {
      throw new Error("Insufficient balance for " + from);
    }
    wallets.updateOne({ user: from }, { $inc: { balance: -amount } });   // debit
    wallets.updateOne({ user: to },   { $inc: { balance:  amount } });   // credit
    session.commitTransaction();                                          // both succeed together
    print("COMMITTED: " + from + " -> " + to + " : " + amount);
  } catch (e) {
    session.abortTransaction();                                           // neither is applied
    print("ABORTED: " + e.message);
  } finally {
    session.endSession();
  }
}

print("Before:");   printjson(db.wallets.find({}, { _id: 0 }).toArray());

transfer("Amit", "Priya", 1500);    // succeeds
print("After successful transfer:"); printjson(db.wallets.find({}, { _id: 0 }).toArray());

transfer("Priya", "Amit", 99999);   // fails -> rolled back, balances unchanged
print("After failed transfer (unchanged):"); printjson(db.wallets.find({}, { _id: 0 }).toArray());
