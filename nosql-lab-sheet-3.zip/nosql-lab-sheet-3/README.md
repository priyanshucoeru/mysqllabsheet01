# BCA305P – NoSQL Database Design: Lab Sheet 3

**Name:** ______________  **Roll No:** ______________

| Q | System | Folder / file |
|---|---|---|
| 1 | Student Activity Tracking | `q01_student_activity/student_activity.js` |
| 2 | Event Logging | `q02_event_logging/event_logging.js` |
| 3 | Mini Blogging Platform | `q03_blogging/blogging.js` |
| 4 | Flexible Product Catalog | `q04_product_catalog/product_catalog.js` |
| 5 | E-Commerce Orders | `q05_ecommerce_orders/ecommerce_orders.js` |
| 6 | Website Analytics | `q06_website_analytics/website_analytics.js` |
| 7 | Content Management System | `q07_cms/cms.js` |
| 8 | Shopping Cart | `q08_shopping_cart/shopping_cart.js` |
| 9 | Reviews & Ratings | `q09_reviews_ratings/reviews_ratings.js` |
| 10 | Inventory Monitoring | `q10_inventory/inventory.js` |
| 11 | Wallet Transfer (Transactions) | `q11_wallet_transactions/` (needs replica set) |
| 12 | Notifications | `q12_notifications/notifications.js` |
| 13 | Course Learning Platform | `q13_course_platform/course_platform.js` |
| 14 | Order Tracking | `q14_order_tracking/order_tracking.js` |
| 15 | Flexible News Database | `q15_news_database/news_database.js` |

## Run
Start MongoDB (`docker run -d --name mongo -p 27017:27017 mongo:7` or a local install), then:
```bash
mongosh q01_student_activity/student_activity.js
```
Each script creates its own database, so scripts don't interfere with each other.

**Q11 note:** transactions only work on a replica set. Follow the steps at the top of `wallet_transfer.js`.

## Upload to GitHub
```bash
git init && git add . && git commit -m "Add NoSQL Lab Sheet 3"
git branch -M main
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```
