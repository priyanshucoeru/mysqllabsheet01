// Run: mongosh order_tracking.js
use("TrackingDB");
db.orders.drop();

// Order with current status + full status history
db.orders.insertMany([
  { order_id: "ORD-1", customer: "Amit", amount: 56000,
    current_status: "Placed",
    status_history: [ { status: "Placed", at: new Date("2026-10-20T09:00:00Z") } ] },
  { order_id: "ORD-2", customer: "Priya", amount: 2500,
    current_status: "Placed",
    status_history: [ { status: "Placed", at: new Date("2026-10-21T10:00:00Z") } ] }
]);

// Move order to a new stage: update current status AND append to history in one atomic update
function updateStatus(orderId, newStatus) {
  db.orders.updateOne({ order_id: orderId },
    { $set: { current_status: newStatus },
      $push: { status_history: { status: newStatus, at: new Date() } } });
}

updateStatus("ORD-1", "Confirmed");
updateStatus("ORD-1", "Shipped");
updateStatus("ORD-1", "Delivered");
updateStatus("ORD-2", "Confirmed");

print("1. Current status of ORD-1");
printjson(db.orders.findOne({ order_id: "ORD-1" }, { _id: 0, order_id: 1, current_status: 1 }));

print("2. Complete status history of ORD-1");
printjson(db.orders.findOne({ order_id: "ORD-1" }, { _id: 0, order_id: 1, status_history: 1 }));

print("3. Latest status taken from history (last element)");
printjson(db.orders.findOne({ order_id: "ORD-2" }, { _id: 0, order_id: 1, status_history: { $slice: -1 } }));

print("4. All orders currently in 'Confirmed' stage");
printjson(db.orders.find({ current_status: "Confirmed" }, { _id: 0, order_id: 1, customer: 1 }).toArray());

print("5. Orders count per current stage");
printjson(db.orders.aggregate([{ $group: { _id: "$current_status", orders: { $sum: 1 } } }]).toArray());

print("6. Time taken from Placed to Delivered for ORD-1 (ms)");
printjson(db.orders.aggregate([
  { $match: { order_id: "ORD-1" } },
  { $project: { _id: 0, order_id: 1,
      placed:    { $first: "$status_history.at" },
      delivered: { $last:  "$status_history.at" } } },
  { $addFields: { duration_ms: { $subtract: ["$delivered", "$placed"] } } }
]).toArray());
