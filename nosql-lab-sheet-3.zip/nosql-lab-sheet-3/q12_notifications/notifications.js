// Run: mongosh notifications.js
use("NotifyDB");
db.notifications.drop();

db.notifications.insertMany([
  { user_id: "U1", type: "message",      title: "New message from Priya",   body: "Hi!",                  is_read: false, created_at: new Date("2026-10-22T09:00:00Z") },
  { user_id: "U1", type: "order_update", title: "Order #1001 shipped",      body: "Arrives in 2 days",    is_read: false, created_at: new Date("2026-10-22T10:00:00Z") },
  { user_id: "U1", type: "system_alert", title: "Password expires soon",    body: "Change within 5 days", is_read: true,  created_at: new Date("2026-10-20T08:00:00Z") },
  { user_id: "U2", type: "message",      title: "New message from Amit",    body: "Call me",              is_read: false, created_at: new Date("2026-10-22T11:00:00Z") },
  { user_id: "U2", type: "order_update", title: "Order #1002 delivered",    body: "Delivered",            is_read: true,  created_at: new Date("2026-10-21T12:00:00Z") },
  { user_id: "U1", type: "system_alert", title: "Maintenance tonight",      body: "12am-2am",             is_read: false, created_at: new Date("2026-10-23T07:00:00Z") }
]);
db.notifications.createIndex({ user_id: 1, is_read: 1 });

print("1. Unread notifications of U1 (newest first)");
printjson(db.notifications.find({ user_id: "U1", is_read: false }, { title: 1, type: 1, _id: 0 }).sort({ created_at: -1 }).toArray());

print("2. Unread count per type for U1");
printjson(db.notifications.aggregate([
  { $match: { user_id: "U1", is_read: false } },
  { $group: { _id: "$type", unread: { $sum: 1 } } }
]).toArray());

print("3. User views ONE notification -> mark as read");
const one = db.notifications.findOne({ user_id: "U1", type: "message", is_read: false });
db.notifications.updateOne({ _id: one._id }, { $set: { is_read: true, read_at: new Date() } });

print("4. User opens notification panel -> mark ALL unread as read");
const res = db.notifications.updateMany({ user_id: "U1", is_read: false }, { $set: { is_read: true, read_at: new Date() } });
print("Updated: " + res.modifiedCount);

print("5. Unread notifications of U1 now");
printjson(db.notifications.find({ user_id: "U1", is_read: false }).toArray());

print("6. Only unread order updates for U2 (none) / all unread overall");
printjson(db.notifications.find({ is_read: false }, { user_id: 1, title: 1, _id: 0 }).toArray());
