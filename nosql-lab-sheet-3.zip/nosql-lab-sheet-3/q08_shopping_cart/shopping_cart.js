// Run: mongosh shopping_cart.js
use("CartDB");
db.carts.drop();

// Cart with embedded items
db.carts.insertOne({ user_id: "U1", items: [], updated_at: new Date() });

// 1. Add products
function addProduct(user, p) {
  // if product already in cart -> increase quantity, else push a new item
  const r = db.carts.updateOne({ user_id: user, "items.product_id": p.product_id },
                               { $inc: { "items.$.quantity": p.quantity }, $set: { updated_at: new Date() } });
  if (r.matchedCount === 0) {
    db.carts.updateOne({ user_id: user }, { $push: { items: p }, $set: { updated_at: new Date() } });
  }
}
addProduct("U1", { product_id: 101, name: "Laptop Bag", price: 1500, quantity: 1 });
addProduct("U1", { product_id: 102, name: "Mouse",      price: 500,  quantity: 2 });
addProduct("U1", { product_id: 103, name: "Keyboard",   price: 1200, quantity: 1 });
addProduct("U1", { product_id: 102, name: "Mouse",      price: 500,  quantity: 1 });   // same product again
print("After adding products:");
printjson(db.carts.findOne({ user_id: "U1" }));

// 2. Change quantity (set Keyboard quantity to 3)
db.carts.updateOne({ user_id: "U1", "items.product_id": 103 }, { $set: { "items.$.quantity": 3 } });
print("After changing keyboard quantity:");
printjson(db.carts.findOne({ user_id: "U1" }).items);

// 3. Remove a product (Laptop Bag)
db.carts.updateOne({ user_id: "U1" }, { $pull: { items: { product_id: 101 } } });
print("After removing Laptop Bag:");
printjson(db.carts.findOne({ user_id: "U1" }).items);

// 4. Cart value
print("Cart value:");
printjson(db.carts.aggregate([
  { $match: { user_id: "U1" } },
  { $project: { _id: 0, user_id: 1, item_count: { $size: "$items" },
      cart_value: { $sum: { $map: { input: "$items", as: "i", in: { $multiply: ["$$i.price", "$$i.quantity"] } } } } } }
]).toArray());
