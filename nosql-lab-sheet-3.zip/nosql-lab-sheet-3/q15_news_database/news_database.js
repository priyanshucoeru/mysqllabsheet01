// Run: mongosh news_database.js
use("NewsDB");
db.articles.drop();

// Articles intentionally have DIFFERENT fields (flexible schema)
db.articles.insertMany([
  { headline: "Budget 2026 announced", author: "Ravi Kumar", category: "Politics",
    location: "New Delhi", tags: ["budget", "economy"], sources: ["PTI", "Government release"],
    published: new Date("2026-10-20") },
  { headline: "Local team wins state cricket final", category: "Sports",
    location: "Dehradun", images: ["final1.jpg", "trophy.jpg"], published: new Date("2026-10-21") },   // no author, tags
  { headline: "New AI chip unveiled", author: "Neha Gupta", category: "Technology",
    tags: ["ai", "hardware"], images: ["chip.png"], published: new Date("2026-10-22") },               // no location
  { headline: "Heavy rain alert in Uttarakhand", location: "Roorkee",
    sources: ["IMD"], published: new Date("2026-10-22") },                                              // no author, category
  { headline: "Stock market hits record high", author: "Priya Singh", category: "Business",
    location: "Mumbai", tags: ["stocks", "economy"], sources: ["Reuters"], video_url: "https://example.com/v1",
    published: new Date("2026-10-23") }
]);

print("1. Articles that HAVE an author field");
printjson(db.articles.find({ author: { $exists: true } }, { headline: 1, author: 1, _id: 0 }).toArray());

print("2. Articles WITHOUT an author");
printjson(db.articles.find({ author: { $exists: false } }, { headline: 1, _id: 0 }).toArray());

print("3. Articles with images");
printjson(db.articles.find({ images: { $exists: true } }, { headline: 1, images: 1, _id: 0 }).toArray());

print("4. Tag 'economy' (documents without tags are skipped safely)");
printjson(db.articles.find({ tags: "economy" }, { headline: 1, _id: 0 }).toArray());

print("5. Category Sports OR location Roorkee (works even if either field is missing)");
printjson(db.articles.find({ $or: [{ category: "Sports" }, { location: "Roorkee" }] }, { headline: 1, _id: 0 }).toArray());

print("6. Articles from source 'PTI' or 'Reuters'");
printjson(db.articles.find({ sources: { $in: ["PTI", "Reuters"] } }, { headline: 1, sources: 1, _id: 0 }).toArray());

print("7. Headline text search (case-insensitive regex 'rain|cricket')");
printjson(db.articles.find({ headline: { $regex: /rain|cricket/i } }, { headline: 1, _id: 0 }).toArray());

print("8. Articles missing category -> show 'Uncategorised' using $ifNull");
printjson(db.articles.aggregate([
  { $project: { _id: 0, headline: 1, category: { $ifNull: ["$category", "Uncategorised"] } } }
]).toArray());

print("9. Articles that have BOTH author and location");
printjson(db.articles.find({ author: { $exists: true }, location: { $exists: true } }, { headline: 1, _id: 0 }).toArray());

print("10. Number of articles per category (missing = null)");
printjson(db.articles.aggregate([{ $group: { _id: { $ifNull: ["$category", "None"] }, count: { $sum: 1 } } }]).toArray());

print("11. Add a new field to one article only (flexible schema)");
db.articles.updateOne({ headline: "New AI chip unveiled" }, { $set: { reporter_phone: "9999999999" } });
