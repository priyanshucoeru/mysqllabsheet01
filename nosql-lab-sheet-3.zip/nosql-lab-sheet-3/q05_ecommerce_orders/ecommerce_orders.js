// Run: mongosh ecommerce_orders.js
use("ShopDB");
db.customers.drop(); db.products.drop(); db.orders.drop();

db.customers.insertMany([
  { _id: 1, name: "Amit Sharma", email: "amit@mail.com", city: "Roorkee" },
  { _id: 2, name: "Priya Singh", email: "priya@mail.com", city: "Delhi" },
  { _id: 3, name: "Rahul Verma", email: "rahul@mail.com", city: "Dehradun" }
]);

db.products.insertMany([
  { _id: 101, name: "Laptop",     price: 55000 },
  { _id: 102, name: "Mouse",      price: 500 },
  { _id: 103, name: "Keyboard",   price: 1200 },
  { _id: 104, name: "Headphones", price: 2500 },
  { _id: 105, name: "Monitor",    price: 9000 }
]);

// Orders reference customers and products (price copied at purchase time)
db.orders.insertMany([
  { _id: 1001, customer_id: 1, order_date: new Date("2026-09-01"),
    items: [ { product_id: 101, qty: 1, price: 55000 }, { product_id: 102, qty: 2, price: 500 } ] },
  { _id: 1002, customer_id: 2, order_date: new Date("2026-09-05"),
    items: [ { product_id: 104, qty: 1, price: 2500 } ] },
  { _id: 1003, customer_id: 1, order_date: new Date("2026-09-20"),
    items: [ { product_id: 103, qty: 1, price: 1200 }, { product_id: 105, qty: 2, price: 9000 } ] },
  { _id: 1004, customer_id: 3, order_date: new Date("2026-10-02"),
    items: [ { product_id: 102, qty: 3, price: 500 } ] },
  { _id: 1005, customer_id: 1, order_date: new Date("2026-10-15"),
    items: [ { product_id: 104, qty: 2, price: 2500 } ] }
]);

print("1. Complete purchase history of customer 1 (Amit)");
printjson(db.orders.aggregate([
  { $match: { customer_id: 1 } },
  { $lookup: { from: "customers", localField: "customer_id", foreignField: "_id", as: "customer" } },
  { $unwind: "$customer" },
  { $unwind: "$items" },
  { $lookup: { from: "products", localField: "items.product_id", foreignField: "_id", as: "product" } },
  { $unwind: "$product" },
  { $project: { _id: 0, order_id: "$_id", order_date: 1, customer: "$customer.name",
                product: "$product.name", qty: "$items.qty", price: "$items.price",
                line_total: { $multiply: ["$items.qty", "$items.price"] } } },
  { $sort: { order_date: 1 } }
]).toArray());

print("2. Total of each order");
printjson(db.orders.aggregate([
  { $project: { customer_id: 1,
      order_total: { $sum: { $map: { input: "$items", as: "i", in: { $multiply: ["$$i.qty", "$$i.price"] } } } } } }
]).toArray());

print("3. Total spent by each customer (with name)");
printjson(db.orders.aggregate([
  { $unwind: "$items" },
  { $group: { _id: "$customer_id", total_spent: { $sum: { $multiply: ["$items.qty", "$items.price"] } },
              orders: { $addToSet: "$_id" } } },
  { $lookup: { from: "customers", localField: "_id", foreignField: "_id", as: "c" } },
  { $unwind: "$c" },
  { $project: { _id: 0, customer: "$c.name", total_spent: 1, order_count: { $size: "$orders" } } },
  { $sort: { total_spent: -1 } }
]).toArray());

print("4. Orders above 10000");
printjson(db.orders.aggregate([
  { $addFields: { total: { $sum: { $map: { input: "$items", as: "i", in: { $multiply: ["$$i.qty", "$$i.price"] } } } } } },
  { $match: { total: { $gt: 10000 } } },
  { $project: { total: 1, customer_id: 1 } }
]).toArray());
