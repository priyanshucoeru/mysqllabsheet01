// Run: mongosh reviews_ratings.js
use("ReviewDB");
db.reviews.drop();

db.reviews.insertMany([
  { product_id: 101, product_name: "Laptop",     customer: "Amit",  rating: 5, comment: "Excellent",     date: new Date("2026-10-01") },
  { product_id: 101, product_name: "Laptop",     customer: "Priya", rating: 4, comment: "Good value",    date: new Date("2026-10-03") },
  { product_id: 101, product_name: "Laptop",     customer: "Rahul", rating: 3, comment: "Heats up",      date: new Date("2026-10-05") },
  { product_id: 102, product_name: "Mouse",      customer: "Amit",  rating: 4, comment: "Smooth",        date: new Date("2026-10-02") },
  { product_id: 102, product_name: "Mouse",      customer: "Neha",  rating: 5, comment: "Love it",       date: new Date("2026-10-04") },
  { product_id: 103, product_name: "Keyboard",   customer: "Karan", rating: 2, comment: "Keys stuck",    date: new Date("2026-10-06") },
  { product_id: 104, product_name: "Headphones", customer: "Priya", rating: 5, comment: "Great sound",   date: new Date("2026-10-07") },
  { product_id: 104, product_name: "Headphones", customer: "Rahul", rating: 4, comment: "Comfortable",   date: new Date("2026-10-08") }
]);

print("1. Average rating and number of reviews per product");
printjson(db.reviews.aggregate([
  { $group: { _id: "$product_id", product: { $first: "$product_name" },
              average_rating: { $avg: "$rating" }, total_reviews: { $sum: 1 } } },
  { $project: { product: 1, total_reviews: 1, average_rating: { $round: ["$average_rating", 2] } } },
  { $sort: { average_rating: -1 } }
]).toArray());

print("2. Products with average rating >= 4");
printjson(db.reviews.aggregate([
  { $group: { _id: "$product_name", avg: { $avg: "$rating" }, reviews: { $sum: 1 } } },
  { $match: { avg: { $gte: 4 } } }
]).toArray());

print("3. Rating distribution (1-5 stars)");
printjson(db.reviews.aggregate([{ $group: { _id: "$rating", count: { $sum: 1 } } }, { $sort: { _id: -1 } }]).toArray());

print("4. Reviews of Laptop, newest first");
printjson(db.reviews.find({ product_name: "Laptop" }, { _id: 0, customer: 1, rating: 1, comment: 1 }).sort({ date: -1 }).toArray());

print("5. Highest-rated product with at least 2 reviews");
printjson(db.reviews.aggregate([
  { $group: { _id: "$product_name", avg: { $avg: "$rating" }, reviews: { $sum: 1 } } },
  { $match: { reviews: { $gte: 2 } } },
  { $sort: { avg: -1 } }, { $limit: 1 }
]).toArray());
