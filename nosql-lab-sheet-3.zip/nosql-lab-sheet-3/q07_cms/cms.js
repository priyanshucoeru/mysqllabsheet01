// Run: mongosh cms.js
use("CMSDB");
db.articles.drop();

db.articles.insertMany([
  { title: "Intro to NoSQL", author: { name: "Amit Sharma", id: 1 }, category: "Database",
    tags: ["nosql", "mongodb"], status: "published", published_on: new Date("2026-09-10"), views: 1200 },
  { title: "Cassandra Basics", author: { name: "Neha Gupta", id: 2 }, category: "Database",
    tags: ["cassandra", "nosql"], status: "published", published_on: new Date("2026-10-01"), views: 640 },
  { title: "Learning Python", author: { name: "Rahul Verma", id: 3 }, category: "Programming",
    tags: ["python", "beginner"], status: "draft", published_on: null, views: 0 },
  { title: "Graph Databases", author: { name: "Amit Sharma", id: 1 }, category: "Database",
    tags: ["neo4j", "graph"], status: "draft", published_on: null, views: 0 },
  { title: "Web Security Tips", author: { name: "Priya Singh", id: 4 }, category: "Security",
    tags: ["security", "web"], status: "published", published_on: new Date("2026-10-15"), views: 310 },
  { title: "Old Redis Guide", author: { name: "Neha Gupta", id: 2 }, category: "Database",
    tags: ["redis"], status: "archived", published_on: new Date("2025-01-05"), views: 90 }
]);

print("1. All published articles");
printjson(db.articles.find({ status: "published" }, { title: 1, _id: 0 }).toArray());

print("2. All unpublished (draft) articles");
printjson(db.articles.find({ status: "draft" }, { title: 1, author: 1, _id: 0 }).toArray());

print("3. Everything NOT published (draft + archived)");
printjson(db.articles.find({ status: { $ne: "published" } }, { title: 1, status: 1, _id: 0 }).toArray());

print("4. Published articles in category Database, newest first");
printjson(db.articles.find({ status: "published", category: "Database" }, { title: 1, published_on: 1, _id: 0 })
  .sort({ published_on: -1 }).toArray());

print("5. Published articles by Amit Sharma");
printjson(db.articles.find({ status: "published", "author.name": "Amit Sharma" }, { title: 1, _id: 0 }).toArray());

print("6. Published in the last 30 days of 2026-10-23");
printjson(db.articles.find({ status: "published", published_on: { $gte: new Date("2026-09-23") } }, { title: 1, _id: 0 }).toArray());

print("7. Articles tagged nosql OR graph");
printjson(db.articles.find({ tags: { $in: ["nosql", "graph"] } }, { title: 1, _id: 0 }).toArray());

print("8. Publish a draft");
db.articles.updateOne({ title: "Learning Python" }, { $set: { status: "published", published_on: new Date() } });

print("9. Count of articles by status");
printjson(db.articles.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]).toArray());

print("10. Top viewed published articles");
printjson(db.articles.find({ status: "published" }, { title: 1, views: 1, _id: 0 }).sort({ views: -1 }).limit(3).toArray());
