// Run: mongosh blogging.js
use("BlogDB");
db.blogs.drop();

db.blogs.insertMany([
  { title: "Getting Started with MongoDB", author: { name: "Amit Sharma", email: "amit@mail.com" },
    category: "Database", tags: ["mongodb", "nosql", "beginner"],
    comments: [ { user: "priya", text: "Very helpful!", date: new Date("2026-10-02") },
                { user: "rahul", text: "Nice intro.",   date: new Date("2026-10-03") } ],
    publication: { status: "published", published_on: new Date("2026-10-01") } },
  { title: "Sharding Explained", author: { name: "Neha Gupta", email: "neha@mail.com" },
    category: "Database", tags: ["mongodb", "sharding", "scalability"],
    comments: [],
    publication: { status: "published", published_on: new Date("2026-10-05") } },
  { title: "Python for Data Science", author: { name: "Rahul Verma", email: "rahul@mail.com" },
    category: "Programming", tags: ["python", "data-science", "beginner"],
    comments: [ { user: "amit", text: "Great examples", date: new Date("2026-10-08") } ],
    publication: { status: "published", published_on: new Date("2026-10-07") } },
  { title: "Intro to Redis", author: { name: "Amit Sharma", email: "amit@mail.com" },
    category: "Database", tags: ["redis", "nosql", "cache"],
    comments: [],
    publication: { status: "draft", published_on: null } },
  { title: "REST API Design", author: { name: "Priya Singh", email: "priya@mail.com" },
    category: "Web", tags: ["api", "web", "beginner"],
    comments: [ { user: "karan", text: "Clear!", date: new Date("2026-10-12") } ],
    publication: { status: "published", published_on: new Date("2026-10-10") } }
]);

print("1. Blogs with tag 'nosql'");
printjson(db.blogs.find({ tags: "nosql" }, { title: 1, _id: 0 }).toArray());

print("2. Blogs having ANY of tags mongodb OR python");
printjson(db.blogs.find({ tags: { $in: ["mongodb", "python"] } }, { title: 1, _id: 0 }).toArray());

print("3. Blogs having ALL tags mongodb AND nosql");
printjson(db.blogs.find({ tags: { $all: ["mongodb", "nosql"] } }, { title: 1, _id: 0 }).toArray());

print("4. Category 'Database' AND tag 'beginner'");
printjson(db.blogs.find({ category: "Database", tags: "beginner" }, { title: 1, _id: 0 }).toArray());

print("5. Category 'Database' OR 'Web', excluding tag 'redis'");
printjson(db.blogs.find({ category: { $in: ["Database", "Web"] }, tags: { $ne: "redis" } },
  { title: 1, category: 1, _id: 0 }).toArray());

print("6. Published blogs with at least one comment");
printjson(db.blogs.find({ "publication.status": "published", "comments.0": { $exists: true } },
  { title: 1, _id: 0 }).toArray());

print("7. Blogs by author Amit Sharma");
printjson(db.blogs.find({ "author.name": "Amit Sharma" }, { title: 1, _id: 0 }).toArray());

print("8. Add a comment to 'Sharding Explained'");
db.blogs.updateOne({ title: "Sharding Explained" },
  { $push: { comments: { user: "amit", text: "Clear explanation", date: new Date() } } });

print("9. Number of blogs per category");
printjson(db.blogs.aggregate([{ $group: { _id: "$category", blogs: { $sum: 1 } } }]).toArray());

print("10. Most used tags");
printjson(db.blogs.aggregate([
  { $unwind: "$tags" },
  { $group: { _id: "$tags", count: { $sum: 1 } } },
  { $sort: { count: -1 } }, { $limit: 5 }
]).toArray());
