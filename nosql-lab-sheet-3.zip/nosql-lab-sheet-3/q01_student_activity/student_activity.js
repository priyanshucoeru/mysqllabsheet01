// Run: mongosh student_activity.js
use("ActivityDB");
db.students.drop();

db.students.insertMany([
  { student_id: 101, name: "Amit Sharma", email: "amit@mail.com", semester: 3,
    courses: ["Database Systems", "Python", "Networks"],
    attendance: { total_classes: 100, attended: 92 },
    skills: ["Python", "SQL", "MongoDB"],
    recent_activities: [
      { type: "quiz",       title: "DB Quiz 1",       date: new Date("2026-10-15") },
      { type: "assignment", title: "Lab Sheet 3",     date: new Date("2026-10-20") } ] },
  { student_id: 102, name: "Priya Singh", email: "priya@mail.com", semester: 3,
    courses: ["Database Systems", "Java"],
    attendance: { total_classes: 100, attended: 68 },
    skills: ["Java", "HTML", "CSS"],
    recent_activities: [
      { type: "seminar", title: "AI Seminar", date: new Date("2026-09-10") } ] },
  { student_id: 103, name: "Rahul Verma", email: "rahul@mail.com", semester: 5,
    courses: ["Python", "Machine Learning"],
    attendance: { total_classes: 100, attended: 80 },
    skills: ["Python", "ML", "Pandas"],
    recent_activities: [
      { type: "hackathon",  title: "Smart India Hackathon", date: new Date("2026-10-18") },
      { type: "assignment", title: "ML Project",            date: new Date("2026-10-21") } ] },
  { student_id: 104, name: "Neha Gupta", email: "neha@mail.com", semester: 5,
    courses: ["Networks", "Machine Learning", "Python"],
    attendance: { total_classes: 100, attended: 95 },
    skills: ["Python", "Networking", "Linux"],
    recent_activities: [] },
  { student_id: 105, name: "Karan Mehta", email: "karan@mail.com", semester: 1,
    courses: ["C Programming"],
    attendance: { total_classes: 100, attended: 55 },
    skills: ["C"],
    recent_activities: [ { type: "quiz", title: "C Quiz", date: new Date("2026-08-01") } ] }
]);

print("1. Students enrolled in 'Python'");
printjson(db.students.find({ courses: "Python" }, { name: 1, _id: 0 }).toArray());

print("2. Students who know BOTH Python and SQL");
printjson(db.students.find({ skills: { $all: ["Python", "SQL"] } }, { name: 1, _id: 0 }).toArray());

print("3. Attendance below 75% (computed)");
printjson(db.students.aggregate([
  { $addFields: { attendance_pct: { $multiply: [{ $divide: ["$attendance.attended", "$attendance.total_classes"] }, 100] } } },
  { $match: { attendance_pct: { $lt: 75 } } },
  { $project: { _id: 0, name: 1, attendance_pct: 1 } }
]).toArray());

print("4. Students with an 'assignment' activity after 2026-10-19");
printjson(db.students.find(
  { recent_activities: { $elemMatch: { type: "assignment", date: { $gte: new Date("2026-10-19") } } } },
  { name: 1, _id: 0 }).toArray());

print("5. Students with NO recent activity");
printjson(db.students.find({ recent_activities: { $size: 0 } }, { name: 1, _id: 0 }).toArray());

print("6. Students enrolled in 3 or more courses");
printjson(db.students.find({ $expr: { $gte: [{ $size: "$courses" }, 3] } }, { name: 1, _id: 0 }).toArray());

print("7. Add a new activity to student 102");
db.students.updateOne({ student_id: 102 },
  { $push: { recent_activities: { type: "quiz", title: "Java Quiz", date: new Date() } } });
printjson(db.students.findOne({ student_id: 102 }, { recent_activities: 1, _id: 0 }));
