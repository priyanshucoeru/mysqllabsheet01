// Run: mongosh product_catalog.js
use("CatalogDB");
db.products.drop();

// Common collection, different attributes per category
db.products.insertMany([
  { sku: "LAP-001", name: "Dell Inspiron 15", category: "laptop", brand: "Dell", price: 55000,
    attributes: { ram_gb: 16, storage_gb: 512, processor: "Intel i5", screen_inch: 15.6 } },
  { sku: "LAP-002", name: "MacBook Air M2",  category: "laptop", brand: "Apple", price: 110000,
    attributes: { ram_gb: 8,  storage_gb: 256, processor: "Apple M2", screen_inch: 13.6 } },
  { sku: "LAP-003", name: "HP Pavilion",     category: "laptop", brand: "HP", price: 62000,
    attributes: { ram_gb: 32, storage_gb: 1024, processor: "Intel i7", screen_inch: 14 } },
  { sku: "MOB-001", name: "Samsung Galaxy S23", category: "mobile", brand: "Samsung", price: 60000,
    attributes: { ram_gb: 8, storage_gb: 256, battery_mah: 3900, camera_mp: 50, os: "Android", has_5g: true } },
  { sku: "MOB-002", name: "iPhone 14",       category: "mobile", brand: "Apple", price: 70000,
    attributes: { ram_gb: 6, storage_gb: 128, battery_mah: 3279, camera_mp: 12, os: "iOS", has_5g: true } },
  { sku: "MOB-003", name: "Redmi Note 12",   category: "mobile", brand: "Xiaomi", price: 16000,
    attributes: { ram_gb: 6, storage_gb: 128, battery_mah: 5000, camera_mp: 48, os: "Android", has_5g: false } },
  { sku: "CAM-001", name: "Canon EOS 200D",  category: "camera", brand: "Canon", price: 48000,
    attributes: { megapixels: 24.1, sensor: "APS-C", lens_mount: "EF-S", video: "1080p", mirrorless: false } },
  { sku: "CAM-002", name: "Sony Alpha A7 III", category: "camera", brand: "Sony", price: 160000,
    attributes: { megapixels: 24.2, sensor: "Full-frame", lens_mount: "E", video: "4K", mirrorless: true } },
  { sku: "CAM-003", name: "Nikon Z50",       category: "camera", brand: "Nikon", price: 85000,
    attributes: { megapixels: 20.9, sensor: "APS-C", lens_mount: "Z", video: "4K", mirrorless: true } }
]);
db.products.createIndex({ category: 1 });

print("1. Laptops with RAM >= 16 GB");
printjson(db.products.find({ category: "laptop", "attributes.ram_gb": { $gte: 16 } }, { name: 1, "attributes.ram_gb": 1, _id: 0 }).toArray());

print("2. Mobiles with 5G and battery > 4000 mAh");
printjson(db.products.find({ category: "mobile", "attributes.has_5g": true, "attributes.battery_mah": { $gt: 4000 } }).toArray());
print("   (none expected: 5G phones above have <= 3900 mAh)  -> relaxing to battery > 3500");
printjson(db.products.find({ category: "mobile", "attributes.has_5g": true, "attributes.battery_mah": { $gt: 3500 } }, { name: 1, _id: 0 }).toArray());

print("3. 4K mirrorless cameras");
printjson(db.products.find({ category: "camera", "attributes.mirrorless": true, "attributes.video": "4K" }, { name: 1, _id: 0 }).toArray());

print("4. Products that HAVE a 'camera_mp' attribute (only mobiles)");
printjson(db.products.find({ "attributes.camera_mp": { $exists: true } }, { name: 1, _id: 0 }).toArray());

print("5. Any product by brand Apple under 100000");
printjson(db.products.find({ brand: "Apple", price: { $lt: 100000 } }, { name: 1, price: 1, _id: 0 }).toArray());

print("6. Average price per category");
printjson(db.products.aggregate([{ $group: { _id: "$category", avg_price: { $avg: "$price" }, count: { $sum: 1 } } }]).toArray());

print("7. Add a new attribute to one product");
db.products.updateOne({ sku: "LAP-001" }, { $set: { "attributes.backlit_keyboard": true } });
