// Run: mongosh course_platform.js
use("LearningDB");
db.instructors.drop(); db.courses.drop(); db.students.drop(); db.enrollments.drop();

db.instructors.insertMany([
  { _id: "I1", name: "Dr. Sharma", expertise: "Databases" },
  { _id: "I2", name: "Prof. Rao",  expertise: "Programming" }
]);

db.courses.insertMany([
  { _id: "C1", title: "MongoDB Fundamentals", instructor_id: "I1",
    modules: [ { no: 1, title: "Intro" }, { no: 2, title: "CRUD" }, { no: 3, title: "Aggregation" }, { no: 4, title: "Sharding" } ] },
  { _id: "C2", title: "Python Basics", instructor_id: "I2",
    modules: [ { no: 1, title: "Syntax" }, { no: 2, title: "Functions" }, { no: 3, title: "OOP" } ] }
]);

db.students.insertMany([
  { _id: "S1", name: "Amit Sharma" }, { _id: "S2", name: "Priya Singh" },
  { _id: "S3", name: "Rahul Verma" }, { _id: "S4", name: "Neha Gupta" }
]);

// Progress stored per enrollment: completed modules list
db.enrollments.insertMany([
  { student_id: "S1", course_id: "C1", completed_modules: [1, 2, 3, 4], progress_pct: 100, completed: true },
  { student_id: "S2", course_id: "C1", completed_modules: [1, 2],       progress_pct: 50,  completed: false },
  { student_id: "S3", course_id: "C1", completed_modules: [],           progress_pct: 0,   completed: false },
  { student_id: "S1", course_id: "C2", completed_modules: [1],          progress_pct: 33,  completed: false },
  { student_id: "S4", course_id: "C2", completed_modules: [1, 2, 3],    progress_pct: 100, completed: true },
  { student_id: "S2", course_id: "C2", completed_modules: [1, 2],       progress_pct: 67,  completed: false }
]);

function withNames(match) {
  return db.enrollments.aggregate([
    { $match: match },
    { $lookup: { from: "students", localField: "student_id", foreignField: "_id", as: "s" } },
    { $lookup: { from: "courses",  localField: "course_id",  foreignField: "_id", as: "c" } },
    { $unwind: "$s" }, { $unwind: "$c" },
    { $project: { _id: 0, student: "$s.name", course: "$c.title", progress_pct: 1, completed: 1 } }
  ]).toArray();
}

print("1. Students who completed a course");
printjson(withNames({ completed: true }));

print("2. Students with progress >= 50% but not completed");
printjson(withNames({ progress_pct: { $gte: 50 }, completed: false }));

print("3. Students who have not started (0%)");
printjson(withNames({ progress_pct: 0 }));

print("4. Students in MongoDB course (C1) with progress < 100");
printjson(withNames({ course_id: "C1", progress_pct: { $lt: 100 } }));

print("5. Student Priya completes module 3 of C1 (update progress)");
db.enrollments.updateOne({ student_id: "S2", course_id: "C1" },
  { $addToSet: { completed_modules: 3 }, $set: { progress_pct: 75 } });

print("6. Average progress per course (with instructor)");
printjson(db.enrollments.aggregate([
  { $group: { _id: "$course_id", avg_progress: { $avg: "$progress_pct" }, learners: { $sum: 1 } } },
  { $lookup: { from: "courses", localField: "_id", foreignField: "_id", as: "c" } },
  { $unwind: "$c" },
  { $lookup: { from: "instructors", localField: "c.instructor_id", foreignField: "_id", as: "i" } },
  { $unwind: "$i" },
  { $project: { _id: 0, course: "$c.title", instructor: "$i.name", learners: 1, avg_progress: { $round: ["$avg_progress", 1] } } }
]).toArray());
