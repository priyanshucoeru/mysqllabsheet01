// Run: mongosh website_analytics.js
use("AnalyticsDB");
db.visits.drop();

const d = (s) => new Date(s);
db.visits.insertMany([
  { page: "/home",     user_id: "U1", device: "mobile",  browser: "Chrome",  location: "Delhi",    timestamp: d("2026-10-20T09:00:00Z") },
  { page: "/home",     user_id: "U2", device: "desktop", browser: "Firefox", location: "Mumbai",   timestamp: d("2026-10-20T09:05:00Z") },
  { page: "/products", user_id: "U1", device: "mobile",  browser: "Chrome",  location: "Delhi",    timestamp: d("2026-10-20T09:07:00Z") },
  { page: "/home",     user_id: "U3", device: "mobile",  browser: "Safari",  location: "Chennai",  timestamp: d("2026-10-20T10:00:00Z") },
  { page: "/about",    user_id: "U4", device: "tablet",  browser: "Chrome",  location: "Pune",     timestamp: d("2026-10-20T11:30:00Z") },
  { page: "/products", user_id: "U2", device: "desktop", browser: "Firefox", location: "Mumbai",   timestamp: d("2026-10-21T08:15:00Z") },
  { page: "/products", user_id: "U5", device: "mobile",  browser: "Chrome",  location: "Delhi",    timestamp: d("2026-10-21T09:45:00Z") },
  { page: "/contact",  user_id: "U3", device: "mobile",  browser: "Safari",  location: "Chennai",  timestamp: d("2026-10-21T12:00:00Z") },
  { page: "/home",     user_id: "U6", device: "desktop", browser: "Edge",    location: "Kolkata",  timestamp: d("2026-10-22T14:20:00Z") },
  { page: "/products", user_id: "U6", device: "desktop", browser: "Edge",    location: "Kolkata",  timestamp: d("2026-10-22T14:25:00Z") },
  { page: "/home",     user_id: "U1", device: "mobile",  browser: "Chrome",  location: "Delhi",    timestamp: d("2026-10-22T18:00:00Z") },
  { page: "/products", user_id: "U7", device: "mobile",  browser: "Chrome",  location: "Delhi",    timestamp: d("2026-10-22T19:10:00Z") }
]);

print("1. Most visited pages");
printjson(db.visits.aggregate([
  { $group: { _id: "$page", visits: { $sum: 1 } } },
  { $sort: { visits: -1 } }
]).toArray());

print("2. Commonly used devices");
printjson(db.visits.aggregate([
  { $group: { _id: "$device", count: { $sum: 1 } } },
  { $sort: { count: -1 } }
]).toArray());

print("3. Browser usage");
printjson(db.visits.aggregate([{ $group: { _id: "$browser", count: { $sum: 1 } } }, { $sort: { count: -1 } }]).toArray());

print("4. Visits by location");
printjson(db.visits.aggregate([{ $group: { _id: "$location", visits: { $sum: 1 } } }, { $sort: { visits: -1 } }]).toArray());

print("5. Unique visitors per page");
printjson(db.visits.aggregate([
  { $group: { _id: "$page", unique_users: { $addToSet: "$user_id" } } },
  { $project: { unique_visitors: { $size: "$unique_users" } } },
  { $sort: { unique_visitors: -1 } }
]).toArray());

print("6. Visits per day");
printjson(db.visits.aggregate([
  { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$timestamp" } }, visits: { $sum: 1 } } },
  { $sort: { _id: 1 } }
]).toArray());

print("7. Most visited page on each device");
printjson(db.visits.aggregate([
  { $group: { _id: { device: "$device", page: "$page" }, visits: { $sum: 1 } } },
  { $sort: { visits: -1 } },
  { $group: { _id: "$_id.device", top_page: { $first: "$_id.page" }, visits: { $first: "$visits" } } }
]).toArray());
