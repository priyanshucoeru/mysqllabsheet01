// Run: mongosh inventory.js
use("InventoryDB");
db.inventory.drop();

db.inventory.insertMany([
  { product: "Laptop",     stock: 4,   min_stock_level: 10, supplier: { name: "TechSupply Co", phone: "9000000001" }, restocking_date: new Date("2026-10-30") },
  { product: "Mouse",      stock: 120, min_stock_level: 50, supplier: { name: "GadgetWorld",   phone: "9000000002" }, restocking_date: new Date("2026-11-15") },
  { product: "Keyboard",   stock: 25,  min_stock_level: 25, supplier: { name: "GadgetWorld",   phone: "9000000002" }, restocking_date: new Date("2026-10-28") },
  { product: "Monitor",    stock: 0,   min_stock_level: 8,  supplier: { name: "ScreenHub",     phone: "9000000003" }, restocking_date: new Date("2026-10-25") },
  { product: "Headphones", stock: 40,  min_stock_level: 15, supplier: { name: "SoundMax",      phone: "9000000004" }, restocking_date: new Date("2026-12-01") },
  { product: "Webcam",     stock: 6,   min_stock_level: 12, supplier: { name: "TechSupply Co", phone: "9000000001" }, restocking_date: new Date("2026-10-27") }
]);

print("1. Products needing immediate restocking (stock <= minimum level)");
printjson(db.inventory.find({ $expr: { $lte: ["$stock", "$min_stock_level"] } },
  { product: 1, stock: 1, min_stock_level: 1, _id: 0 }).toArray());

print("2. Out of stock");
printjson(db.inventory.find({ stock: 0 }, { product: 1, supplier: 1, _id: 0 }).toArray());

print("3. Shortfall = how many units to order, most urgent first");
printjson(db.inventory.aggregate([
  { $match: { $expr: { $lte: ["$stock", "$min_stock_level"] } } },
  { $project: { _id: 0, product: 1, stock: 1, min_stock_level: 1,
                shortfall: { $subtract: ["$min_stock_level", "$stock"] }, supplier: "$supplier.name" } },
  { $sort: { shortfall: -1 } }
]).toArray());

print("4. Low-stock products grouped by supplier (who to call)");
printjson(db.inventory.aggregate([
  { $match: { $expr: { $lte: ["$stock", "$min_stock_level"] } } },
  { $group: { _id: "$supplier.name", products: { $push: "$product" }, phone: { $first: "$supplier.phone" } } }
]).toArray());

print("5. Restocking due within the next 7 days (from 2026-10-23)");
printjson(db.inventory.find({ restocking_date: { $gte: new Date("2026-10-23"), $lte: new Date("2026-10-30") } },
  { product: 1, restocking_date: 1, _id: 0 }).toArray());

print("6. Restock Monitor: add 20 units");
db.inventory.updateOne({ product: "Monitor" }, { $inc: { stock: 20 } });
printjson(db.inventory.findOne({ product: "Monitor" }, { product: 1, stock: 1, _id: 0 }));
