// Run: mongosh event_logging.js
use("LogDB");
db.events.drop();

const t = (min) => new Date(Date.now() - min * 60 * 1000);   // "min minutes ago"

db.events.insertMany([
  { user: "amit",  event_type: "login",           ip: "10.0.0.1", timestamp: t(120) },
  { user: "rahul", event_type: "failed-login",    ip: "10.0.0.9", timestamp: t(60) },
  { user: "rahul", event_type: "failed-login",    ip: "10.0.0.9", timestamp: t(58) },
  { user: "rahul", event_type: "failed-login",    ip: "10.0.0.9", timestamp: t(57) },
  { user: "rahul", event_type: "failed-login",    ip: "10.0.0.9", timestamp: t(55) },
  { user: "priya", event_type: "failed-login",    ip: "10.0.0.5", timestamp: t(50) },
  { user: "priya", event_type: "login",           ip: "10.0.0.5", timestamp: t(49) },
  { user: "amit",  event_type: "file-upload",     ip: "10.0.0.1", timestamp: t(40), file: "report.pdf" },
  { user: "priya", event_type: "file-upload",     ip: "10.0.0.5", timestamp: t(35), file: "notes.docx" },
  { user: "amit",  event_type: "password-change", ip: "10.0.0.1", timestamp: t(30) },
  { user: "amit",  event_type: "logout",          ip: "10.0.0.1", timestamp: t(20) },
  { user: "priya", event_type: "logout",          ip: "10.0.0.5", timestamp: t(10) },
  { user: "karan", event_type: "failed-login",    ip: "10.0.0.7", timestamp: t(8) },
  { user: "karan", event_type: "failed-login",    ip: "10.0.0.7", timestamp: t(7) }
]);
db.events.createIndex({ event_type: 1, user: 1 });

print("1. All failed-login events");
printjson(db.events.find({ event_type: "failed-login" }, { _id: 0 }).toArray());

print("2. Users with 3 or more failed logins (repeated attempts)");
printjson(db.events.aggregate([
  { $match: { event_type: "failed-login" } },
  { $group: { _id: "$user", attempts: { $sum: 1 }, last_attempt: { $max: "$timestamp" } } },
  { $match: { attempts: { $gte: 3 } } },
  { $sort: { attempts: -1 } }
]).toArray());

print("3. IPs with repeated failed logins");
printjson(db.events.aggregate([
  { $match: { event_type: "failed-login" } },
  { $group: { _id: "$ip", attempts: { $sum: 1 } } },
  { $match: { attempts: { $gte: 3 } } }
]).toArray());

print("4. Most frequently occurring events");
printjson(db.events.aggregate([
  { $group: { _id: "$event_type", count: { $sum: 1 } } },
  { $sort: { count: -1 } }
]).toArray());

print("5. Events per user");
printjson(db.events.aggregate([
  { $group: { _id: "$user", total_events: { $sum: 1 } } },
  { $sort: { total_events: -1 } }
]).toArray());

print("6. Events in the last 30 minutes");
printjson(db.events.find({ timestamp: { $gte: t(30) } }, { _id: 0 }).toArray());
