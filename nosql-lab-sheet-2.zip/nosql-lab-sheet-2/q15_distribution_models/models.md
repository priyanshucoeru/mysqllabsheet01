# Q15 – Database Distribution Models

## 1. Single Server
```
 [Client] ---> [ DB Server ]
```
- **Data distribution:** all data lives on one machine.
- **Failure handling:** none – if the server fails, the system is down (backups needed).
- **Advantage:** simplest to set up; no distribution complexity, strong consistency.
- **Limitation:** limited by one machine; single point of failure.
- **Application:** small business apps, development/testing, college project.

## 2. Sharding
```
 [Client] ---> [ Router ]
                 |    |    |
              [Sh1][Sh2][Sh3]   (each shard holds a different subset)
```
- **Data distribution:** data is split horizontally by a shard key (range/hash); each shard stores a different part.
- **Failure handling:** if a shard fails, only its part of the data becomes unavailable (unless replicated).
- **Advantage:** horizontal scaling of storage and throughput.
- **Limitation:** complex; poor shard key → hot spots; no fault tolerance alone.
- **Application:** large e-commerce catalogs, big social-media data.

## 3. Master–Slave (Primary–Secondary) Replication
```
          writes
 [Client] -------> [ Master ]
 [Client] <------- [ Slave 1 ]   <-- copy of data
 reads    <------- [ Slave 2 ]   <-- copy of data
```
- **Data distribution:** every node has a full copy; all writes go to the master and are copied to slaves.
- **Failure handling:** if the master fails, a slave is promoted (election/failover). If a slave fails, others serve reads.
- **Advantage:** high availability and read scalability.
- **Limitation:** writes limited to one master; replication lag; master is a bottleneck.
- **Application:** read-heavy systems like blogs, reporting dashboards, MongoDB replica sets.

## 4. Peer-to-Peer Replication
```
      [Node A] <----> [Node B]
          \            /
           \          /
            [Node C]          (all nodes equal, any can read/write)
```
- **Data distribution:** data is spread over a ring and replicated to N peers (replication factor); every node can accept reads and writes.
- **Failure handling:** other peers keep serving; hinted handoff and repair bring a recovered node back up to date.
- **Advantage:** no single point of failure; writes scale with nodes.
- **Limitation:** eventual consistency; conflict resolution needed.
- **Application:** IoT/time-series data, messaging, always-on services (Cassandra).

## 5. Sharding + Replication
```
                [ Router ]
               /          \
        Shard 1            Shard 2
     [P] [S] [S]         [P] [S] [S]
```
- **Data distribution:** data is partitioned by shard key into shards, and each shard is a replica set holding multiple copies.
- **Failure handling:** a failed primary in a shard is replaced by an elected secondary; other shards are unaffected.
- **Advantage:** both horizontal scalability and high availability.
- **Limitation:** most complex and costly (more servers, more operations work).
- **Application:** large-scale production systems – banking platforms, Netflix/Uber-scale services.

## Summary

| Model | Scalability | Fault tolerance | Complexity |
|---|---|---|---|
| Single server | Low | None | Very low |
| Sharding | High | Low | Medium |
| Master–Slave | Reads only | Good | Medium |
| Peer-to-Peer | High (reads+writes) | Very good | Medium-high |
| Sharding + Replication | Very high | Very good | High |
