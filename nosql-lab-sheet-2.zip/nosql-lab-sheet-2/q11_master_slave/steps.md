# Q11 – Primary–Secondary Replication (MongoDB)

```bash
docker compose up -d && sleep 10

# 1 & 2. Configure primary (mongo1) + secondaries (mongo2, mongo3)
docker exec mongo1 mongosh --quiet --eval '
rs.initiate({_id:"rs0", members:[
  {_id:0, host:"mongo1:27017", priority:2},
  {_id:1, host:"mongo2:27017"},
  {_id:2, host:"mongo3:27017"}]})'
sleep 10
docker exec mongo1 mongosh --quiet --eval 'rs.status().members.map(m=>m.name+" -> "+m.stateStr)'

# 3. Insert data into the primary
docker exec mongo1 mongosh --quiet --eval '
db.getSiblingDB("CollegeDB").Students.insertMany([
 {Student_ID:101,Name:"Amit",Course:"BCA",Marks:78},
 {Student_ID:102,Name:"Priya",Course:"MCA",Marks:85},
 {Student_ID:103,Name:"Rahul",Course:"BCA",Marks:69}])'

# 4. Verify replication on a secondary
docker exec mongo2 mongosh --quiet --eval '
db.getMongo().setReadPref("secondary");
printjson(db.getSiblingDB("CollegeDB").Students.find().toArray())'

# 5. Failover: stop the primary
docker stop mongo1
sleep 15
docker exec mongo2 mongosh --quiet --eval 'rs.status().members.map(m=>m.name+" -> "+m.stateStr)'
# A secondary is now PRIMARY. Bring the old one back:
docker start mongo1
```

## What happens when the primary becomes unavailable?
The secondaries detect missing heartbeats (~10 s) and hold an **automatic election**. The secondary with the most up-to-date data wins and becomes the new primary. Writes resume on it. When the old primary returns, it rejoins as a **secondary** and syncs missing data. During the election (a few seconds) writes are unavailable.
