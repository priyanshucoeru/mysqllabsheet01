// Runs against mongos
db = db.getSiblingDB("CollegeDB");
db.students.drop();

// 3. Enable sharding. 2. Shard key = hashed Student_ID (even distribution)
sh.enableSharding("CollegeDB");
sh.shardCollection("CollegeDB.students", { Student_ID: "hashed" });

// 1 & 4. Sample dataset (24 records), distributed automatically by shard key
const courses = ["BCA", "MCA", "BTech", "MBA"];
let docs = [];
for (let i = 1; i <= 24; i++) {
  docs.push({ Student_ID: 100 + i, Name: "Student" + i,
              Course: courses[i % 4], Semester: (i % 6) + 1,
              Marks: 50 + Math.floor(Math.random() * 50) });
}
db.students.insertMany(docs);

// 5. Verify distribution
print("Total documents: " + db.students.countDocuments());
db.students.getShardDistribution();
printjson(sh.status());
