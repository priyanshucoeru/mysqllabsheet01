#!/bin/bash
# Usage: bash setup.sh   (requires Docker)
set -e
docker compose up -d
echo "Waiting for containers..."; sleep 15

docker exec configsvr mongosh --quiet --eval 'rs.initiate({_id:"cfgrs",configsvr:true,members:[{_id:0,host:"configsvr:27017"}]})'
docker exec shard1    mongosh --quiet --eval 'rs.initiate({_id:"shard1rs",members:[{_id:0,host:"shard1:27017"}]})'
docker exec shard2    mongosh --quiet --eval 'rs.initiate({_id:"shard2rs",members:[{_id:0,host:"shard2:27017"}]})'
sleep 15

docker exec mongos mongosh --quiet --eval 'sh.addShard("shard1rs/shard1:27017"); sh.addShard("shard2rs/shard2:27017")'
docker cp sharding.js mongos:/sharding.js
docker exec mongos mongosh --quiet /sharding.js
