# Sharding – shard key and benefits

**Shard key used:** `Student_ID` with *hashed* sharding. Hashing spreads consecutive IDs evenly across shards and avoids hot spots. (Range sharding would keep neighbouring IDs together – good for range queries but can create hot shards.)

**Benefits**
1. **Horizontal scalability** – add shards to hold more data than one server can.
2. **Higher throughput** – reads/writes are spread over multiple machines.
3. **Better performance** – each shard handles a smaller dataset; queries with the shard key go to one shard only.
4. **Larger storage** – total capacity = sum of all shards.

**Limitation:** more complex setup; choosing a poor shard key causes uneven load. Each shard should itself be a replica set for fault tolerance (see Q13).
