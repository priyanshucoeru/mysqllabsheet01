// Run:  mongosh mapreduce.js
use("CollegeDB");
db.students_mr.drop();
db.students_mr.insertMany([
  { Student_ID: 101, Name: "Amit Sharma", Course: "BCA",   Marks: 78 },
  { Student_ID: 102, Name: "Priya Singh", Course: "BCA",   Marks: 85 },
  { Student_ID: 103, Name: "Rahul Verma", Course: "MCA",   Marks: 69 },
  { Student_ID: 104, Name: "Neha Gupta",  Course: "BTech", Marks: 91 },
  { Student_ID: 105, Name: "Karan Mehta", Course: "MCA",   Marks: 74 },
  { Student_ID: 106, Name: "Sana Khan",   Course: "BCA",   Marks: 90 },
  { Student_ID: 107, Name: "Vikas Rao",   Course: "BTech", Marks: 66 }
]);

// MAP: emit (course, {count:1, total:marks}) for each student
var mapFn = function () {
  emit(this.Course, { count: 1, total: this.Marks });
};

// REDUCE: combine all values of the same key
var reduceFn = function (key, values) {
  var result = { count: 0, total: 0 };
  values.forEach(function (v) { result.count += v.count; result.total += v.total; });
  return result;
};

// FINALIZE: compute the average
var finalizeFn = function (key, value) {
  value.average = value.total / value.count;
  return value;
};

print("=== MapReduce result: number of students and average marks per course ===");
printjson(db.students_mr.mapReduce(mapFn, reduceFn,
  { out: { inline: 1 }, finalize: finalizeFn }));

// mapReduce is deprecated in newer MongoDB; this aggregation gives the same result:
print("=== Same result with aggregation pipeline (modern equivalent) ===");
printjson(db.students_mr.aggregate([
  { $group: { _id: "$Course", count: { $sum: 1 }, average: { $avg: "$Marks" } } }
]).toArray());
