"""Pure-Python MapReduce demo – shows the Map, Shuffle and Reduce phases.
Run:  python mapreduce.py   (no libraries needed)"""
from collections import defaultdict

students = [
    (101, "Amit Sharma", "BCA",   78),
    (102, "Priya Singh", "BCA",   85),
    (103, "Rahul Verma", "MCA",   69),
    (104, "Neha Gupta",  "BTech", 91),
    (105, "Karan Mehta", "MCA",   74),
    (106, "Sana Khan",   "BCA",   90),
    (107, "Vikas Rao",   "BTech", 66),
]

# ---- MAP: (Student_ID, Name, Course, Marks) -> (Course, Marks)
mapped = [(course, marks) for (_id, _name, course, marks) in students]
print("MAP output:")
for kv in mapped:
    print("  ", kv)

# ---- SHUFFLE: group values by key
groups = defaultdict(list)
for k, v in mapped:
    groups[k].append(v)
print("\nSHUFFLE output:")
for k, v in groups.items():
    print("  ", k, v)

# ---- REDUCE: count and average per course
print("\nREDUCE output:")
for course, marks in groups.items():
    print(f"   {course}: students = {len(marks)}, average marks = {sum(marks)/len(marks):.2f}")
