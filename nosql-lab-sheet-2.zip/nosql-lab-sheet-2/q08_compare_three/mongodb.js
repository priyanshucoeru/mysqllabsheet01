// mongosh mongodb.js
use("CollegeDB");
db.Students.drop();
db.Students.insertMany([
  { Student_ID: 101, Name: "Amit Sharma", Course: "BCA",   Semester: 3, Marks: 78 },
  { Student_ID: 102, Name: "Priya Singh", Course: "BCA",   Semester: 3, Marks: 85 },
  { Student_ID: 103, Name: "Rahul Verma", Course: "MCA",   Semester: 1, Marks: 69 },
  { Student_ID: 104, Name: "Neha Gupta",  Course: "BTech", Semester: 5, Marks: 91 },
  { Student_ID: 105, Name: "Karan Mehta", Course: "MCA",   Semester: 2, Marks: 74 }
]);
printjson(db.Students.find({ Course: "MCA" }).toArray());
