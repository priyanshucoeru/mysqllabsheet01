# MongoDB vs Cassandra vs Neo4j

| Aspect | MongoDB | Cassandra | Neo4j |
|---|---|---|---|
| **Type** | Document store | Wide-column store | Graph database |
| **Data model** | JSON/BSON documents in collections; nested docs & arrays | Tables with rows, partition key + clustering columns | Nodes, relationships and properties (property graph) |
| **Storage structure** | BSON documents (WiredTiger engine, B-tree) | Partitions on a token ring; LSM-tree (memtable → SSTables) | Native graph storage: nodes, relationships and properties stored as linked records |
| **Query method** | MongoDB Query API / aggregation pipeline | CQL (SQL-like, no joins, queries driven by partition key) | Cypher (pattern-matching language) |
| **Scalability** | Horizontal via sharding + replica sets (primary-secondary) | Excellent linear horizontal scaling, peer-to-peer, no single point of failure | Vertical mainly; clustering (Enterprise) gives read scaling/fault tolerance; sharding is harder |
| **Consistency** | Strong by default (reads from primary) | Tunable (ONE, QUORUM, ALL) – eventual by default | ACID transactions |
| **Suitable applications** | CMS, catalogs, user profiles, mobile apps | IoT, time-series, messaging, logging, very high write volume | Social networks, recommendation engines, fraud detection, knowledge graphs |
