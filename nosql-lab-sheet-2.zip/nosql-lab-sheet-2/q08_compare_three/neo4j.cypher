CREATE (:Student {id:101, name:'Amit Sharma',  semester:3, marks:78}),
       (:Student {id:102, name:'Priya Singh',  semester:3, marks:85}),
       (:Student {id:103, name:'Rahul Verma',  semester:1, marks:69}),
       (:Student {id:104, name:'Neha Gupta',   semester:5, marks:91}),
       (:Student {id:105, name:'Karan Mehta',  semester:2, marks:74});
CREATE (:Course {name:'BCA'}), (:Course {name:'MCA'}), (:Course {name:'BTech'});
MATCH (s:Student),(c:Course)
WHERE (s.id IN [101,102] AND c.name='BCA')
   OR (s.id IN [103,105] AND c.name='MCA')
   OR (s.id = 104        AND c.name='BTech')
CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student)-[:ENROLLED_IN]->(:Course {name:'MCA'}) RETURN s.name, s.marks;
