# Q12 – Peer-to-Peer Replication (Cassandra)

```bash
# 1. Configure multiple nodes (wait until each shows UN before starting the next)
docker compose up -d cass1   # wait ~60-90 s
docker compose up -d cass2   # wait ~60-90 s
docker compose up -d cass3
docker exec cass1 nodetool status          # all three should be UN (Up/Normal)

# 2 & 3. Create keyspace + insert data via cass1
docker exec -i cass1 cqlsh < p2p.cql

# 4. Verify data availability across nodes
docker exec cass2 cqlsh -e "SELECT * FROM collegedb.students;"
docker exec cass3 cqlsh -e "SELECT * FROM collegedb.students;"
docker exec cass1 nodetool getendpoints collegedb students 101   # shows which nodes hold the row

# Fault tolerance: kill one node, data is still readable
docker stop cass3
docker exec cass1 cqlsh -e "CONSISTENCY QUORUM; SELECT * FROM collegedb.students;"
docker start cass3
```

## 5. Peer-to-peer vs Master-Slave

| | Peer-to-Peer (Cassandra) | Master-Slave (MongoDB RS) |
|---|---|---|
| Roles | All nodes equal | One primary, others secondary |
| Writes | Accepted by **any** node | Only the primary |
| Single point of failure | None | Primary (until election) |
| Failover | No election; other nodes keep serving | Election needed |
| Consistency | Tunable / eventual | Strong from primary |
| Write scalability | Scales with nodes | Limited by the primary |
