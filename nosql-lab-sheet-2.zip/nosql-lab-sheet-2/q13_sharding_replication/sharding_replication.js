db = db.getSiblingDB("CollegeDB");
db.students.drop();

sh.enableSharding("CollegeDB");
sh.shardCollection("CollegeDB.students", { Student_ID: "hashed" });

// 3. Insert sample data
const courses = ["BCA", "MCA", "BTech", "MBA"];
let docs = [];
for (let i = 1; i <= 30; i++) {
  docs.push({ Student_ID: 100 + i, Name: "Student" + i, Course: courses[i % 4],
              Semester: (i % 6) + 1, Marks: 50 + Math.floor(Math.random() * 50) });
}
db.students.insertMany(docs);

// 4. Verify data distribution
print("Total: " + db.students.countDocuments());
db.students.getShardDistribution();
