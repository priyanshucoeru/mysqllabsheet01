# How Sharding + Replication gives scalability AND fault tolerance

```
              Application
                  |
               [mongos]  <--- config server (metadata: which chunk is on which shard)
              /        \
        Shard 1          Shard 2
   (replica set)      (replica set)
   P  S  S             P  S  S
```
- **Scalability (sharding):** data is split by the shard key across shards. Adding shards adds storage and throughput.
- **Fault tolerance (replication):** every shard keeps 3 copies. If a shard's primary fails, a secondary is elected primary automatically – no data loss, no downtime for that shard's data.
- **Together:** capacity and load scale horizontally, while each piece of data survives node failures.

**Test failover:** `docker stop s1n1` then `docker exec s1n2 mongosh --quiet --eval 'rs.status().members.map(m=>m.name+" "+m.stateStr)'` – a new PRIMARY appears and queries via mongos still work.
