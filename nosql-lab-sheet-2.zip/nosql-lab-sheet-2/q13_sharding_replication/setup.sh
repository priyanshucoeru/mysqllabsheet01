#!/bin/bash
# Usage: bash setup.sh
set -e
docker compose up -d
echo "Waiting for containers..."; sleep 20

docker exec configsvr mongosh --quiet --eval 'rs.initiate({_id:"cfgrs",configsvr:true,members:[{_id:0,host:"configsvr:27017"}]})'

# 1 & 2. Two shards, each is a 3-member replica set
docker exec s1n1 mongosh --quiet --eval 'rs.initiate({_id:"shard1rs",members:[
  {_id:0,host:"s1n1:27017"},{_id:1,host:"s1n2:27017"},{_id:2,host:"s1n3:27017"}]})'
docker exec s2n1 mongosh --quiet --eval 'rs.initiate({_id:"shard2rs",members:[
  {_id:0,host:"s2n1:27017"},{_id:1,host:"s2n2:27017"},{_id:2,host:"s2n3:27017"}]})'
sleep 25

docker exec mongos mongosh --quiet --eval '
sh.addShard("shard1rs/s1n1:27017,s1n2:27017,s1n3:27017");
sh.addShard("shard2rs/s2n1:27017,s2n2:27017,s2n3:27017");'

docker cp sharding_replication.js mongos:/sr.js
docker exec mongos mongosh --quiet /sr.js

# 5. Verify replica availability
echo "--- Shard 1 members ---"
docker exec s1n1 mongosh --quiet --eval 'rs.status().members.map(m=>m.name+" -> "+m.stateStr)'
echo "--- Shard 2 members ---"
docker exec s2n1 mongosh --quiet --eval 'rs.status().members.map(m=>m.name+" -> "+m.stateStr)'
