// Run:  mongosh orders.js
use("CollegeDB");
db.Orders.drop();

// 1. Insert at least five orders (customer + products embedded)
db.Orders.insertMany([
  { order_id: 1, customer: { name: "Amit Sharma", email: "amit@mail.com", city: "Roorkee" },
    products: [ { name: "Laptop", price: 55000, quantity: 1 }, { name: "Mouse", price: 500, quantity: 2 } ] },
  { order_id: 2, customer: { name: "Priya Singh", email: "priya@mail.com", city: "Delhi" },
    products: [ { name: "Phone", price: 20000, quantity: 1 }, { name: "Cover", price: 300, quantity: 3 } ] },
  { order_id: 3, customer: { name: "Rahul Verma", email: "rahul@mail.com", city: "Dehradun" },
    products: [ { name: "Keyboard", price: 1200, quantity: 1 } ] },
  { order_id: 4, customer: { name: "Amit Sharma", email: "amit@mail.com", city: "Roorkee" },
    products: [ { name: "Headphones", price: 2500, quantity: 2 }, { name: "Pen Drive", price: 600, quantity: 4 } ] },
  { order_id: 5, customer: { name: "Neha Gupta", email: "neha@mail.com", city: "Haridwar" },
    products: [ { name: "Monitor", price: 9000, quantity: 2 } ] }
]);

print("2. Orders of customer 'Amit Sharma'");
printjson(db.Orders.find({ "customer.name": "Amit Sharma" }).toArray());

print("3. Update quantity of Mouse in order 1 to 5");
db.Orders.updateOne(
  { order_id: 1, "products.name": "Mouse" },
  { $set: { "products.$.quantity": 5 } }
);
printjson(db.Orders.findOne({ order_id: 1 }));

print("4. Total order amount using aggregation");
printjson(db.Orders.aggregate([
  { $unwind: "$products" },
  { $group: {
      _id: "$order_id",
      customer: { $first: "$customer.name" },
      total_amount: { $sum: { $multiply: ["$products.price", "$products.quantity"] } }
  } },
  { $sort: { _id: 1 } }
]).toArray());

print("5. Orders above 20000");
printjson(db.Orders.aggregate([
  { $addFields: { total_amount: { $sum: {
      $map: { input: "$products", as: "p",
              in: { $multiply: ["$$p.price", "$$p.quantity"] } } } } } },
  { $match: { total_amount: { $gt: 20000 } } },
  { $project: { _id: 0, order_id: 1, "customer.name": 1, total_amount: 1 } }
]).toArray());
