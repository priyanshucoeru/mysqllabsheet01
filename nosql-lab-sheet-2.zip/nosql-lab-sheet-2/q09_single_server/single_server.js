// mongosh single_server.js
use("LabDB");
db.employees.drop();

print("Server info:");
printjson({ version: db.version(), host: db.hostInfo().system.hostname });

// 3-4. Create DB + collection, insert sample records
db.employees.insertMany([
  { emp_id: 1, name: "Asha",  dept: "IT",      salary: 50000 },
  { emp_id: 2, name: "Ravi",  dept: "HR",      salary: 42000 },
  { emp_id: 3, name: "Meena", dept: "Finance", salary: 55000 },
  { emp_id: 4, name: "Vijay", dept: "IT",      salary: 61000 },
  { emp_id: 5, name: "Sita",  dept: "HR",      salary: 39000 }
]);

// 5. CRUD
print("READ all");        printjson(db.employees.find().toArray());
print("READ dept = IT");  printjson(db.employees.find({ dept: "IT" }).toArray());
print("UPDATE");          db.employees.updateOne({ emp_id: 2 }, { $set: { salary: 45000 } });
printjson(db.employees.findOne({ emp_id: 2 }));
print("DELETE");          db.employees.deleteOne({ emp_id: 5 });

// 6. Verify
print("Remaining documents: " + db.employees.countDocuments());
print("Server status OK: " + (db.adminCommand({ ping: 1 }).ok === 1));
