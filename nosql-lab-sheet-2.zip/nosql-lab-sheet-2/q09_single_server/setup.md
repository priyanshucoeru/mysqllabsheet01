# Q9 – MongoDB on a single server / local machine

## 1. Install
- **Windows**: download MongoDB Community Server (MSI) + MongoDB Shell (`mongosh`) from mongodb.com/try/download
- **Ubuntu**: follow the official apt repo steps, then `sudo apt install -y mongodb-org`
- **macOS**: `brew tap mongodb/brew && brew install mongodb-community`
- **Docker (easiest)**: `docker run -d --name mongo-single -p 27017:27017 mongo:7`

## 2. Start the server
- Linux: `sudo systemctl start mongod && sudo systemctl status mongod`
- macOS: `brew services start mongodb-community`
- Windows: service "MongoDB Server" starts automatically (or run `mongod`)

## 3. Connect and run the script
```
mongosh                      # connect to localhost:27017
mongosh single_server.js     # run the whole demo
```
Take screenshots of: server running, `mongosh` connection, script output.
