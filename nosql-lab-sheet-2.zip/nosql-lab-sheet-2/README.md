# BCA305P – Lab Sheet 2: NoSQL Database Design

**Name:** ______________  **Roll No:** ______________  **Course:** BCA

| Q | Topic | Folder | Tool |
|---|---|---|---|
| 1 | MySQL vs MongoDB | `q01_mysql_vs_mongodb` | MySQL, MongoDB |
| 2 | MongoDB CRUD | `q02_mongodb_crud` | MongoDB |
| 3 | Embedded orders + aggregation | `q03_orders_embedded` | MongoDB |
| 4 | Key-value student system | `q04_redis` | Redis |
| 5 | Cassandra student table | `q05_cassandra` | Cassandra |
| 6 | HBase students table | `q06_hbase` | HBase |
| 7 | Student–Course graph | `q07_neo4j` | Neo4j |
| 8 | MongoDB vs Cassandra vs Neo4j | `q08_compare_three` | all three |
| 9 | Single server deployment | `q09_single_server` | MongoDB |
| 10 | Sharding | `q10_sharding` | MongoDB + Docker |
| 11 | Master–Slave replication | `q11_master_slave` | MongoDB + Docker |
| 12 | Peer-to-peer replication | `q12_peer_to_peer` | Cassandra + Docker |
| 13 | Sharding + Replication | `q13_sharding_replication` | MongoDB + Docker |
| 14 | MapReduce | `q14_mapreduce` | MongoDB / Python |
| 15 | Distribution models | `q15_distribution_models` | Theory + diagrams |

## Upload to GitHub
```bash
git init
git add .
git commit -m "Add NoSQL Lab Sheet 2"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
(Create the empty repo on github.com first.)

> Tip: add screenshots of your terminal output for each question in a `screenshots/` folder.
