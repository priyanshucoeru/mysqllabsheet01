// Run:  mongosh collegedb.js
use("CollegeDB");
db.Students.drop();

// Insert at least five documents
db.Students.insertMany([
  { Student_ID: 101, Name: "Amit Sharma", Course: "BCA",   Semester: 3, Marks: 78 },
  { Student_ID: 102, Name: "Priya Singh", Course: "BCA",   Semester: 3, Marks: 85 },
  { Student_ID: 103, Name: "Rahul Verma", Course: "MCA",   Semester: 1, Marks: 69 },
  { Student_ID: 104, Name: "Neha Gupta",  Course: "BTech", Semester: 5, Marks: 91 },
  { Student_ID: 105, Name: "Karan Mehta", Course: "MCA",   Semester: 2, Marks: 74 }
]);

print("1. Display all documents");
printjson(db.Students.find().toArray());

print("2. Students from course MCA");
printjson(db.Students.find({ Course: "MCA" }).toArray());

print("3. Update marks of Student_ID 101 to 88");
db.Students.updateOne({ Student_ID: 101 }, { $set: { Marks: 88 } });
printjson(db.Students.findOne({ Student_ID: 101 }));

print("4. Delete one student (Student_ID 105)");
db.Students.deleteOne({ Student_ID: 105 });

print("5. Total number of students");
print(db.Students.countDocuments());
