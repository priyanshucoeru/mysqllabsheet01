-- Run in MySQL:  mysql -u root -p < student.sql
CREATE DATABASE IF NOT EXISTS CollegeDB;
USE CollegeDB;

DROP TABLE IF EXISTS Student;
CREATE TABLE Student (
    Student_ID INT PRIMARY KEY,
    Name       VARCHAR(50) NOT NULL,
    Course     VARCHAR(30),
    Semester   INT,
    Marks      INT
);

INSERT INTO Student VALUES
(101, 'Amit Sharma',  'BCA',  3, 78),
(102, 'Priya Singh',  'BCA',  3, 85),
(103, 'Rahul Verma',  'MCA',  1, 69),
(104, 'Neha Gupta',   'BTech',5, 91),
(105, 'Karan Mehta',  'MCA',  2, 74);

SELECT * FROM Student;
