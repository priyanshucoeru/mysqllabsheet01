# MySQL (RDBMS) vs MongoDB (Document NoSQL)

| Feature | MySQL | MongoDB |
|---|---|---|
| **Schema** | Fixed, predefined (table + typed columns). Changing it needs `ALTER TABLE`. | Schema-less / flexible. Each document can have different fields. |
| **Data storage** | Rows in tables; relations through foreign keys and JOINs. | BSON (binary JSON) documents in collections; related data can be embedded. |
| **Flexibility** | Low – every row has the same columns. | High – add new fields to any document without migration. |
| **Scalability** | Mainly vertical (bigger server); horizontal scaling is complex. | Built for horizontal scaling (sharding + replica sets). |
| **Query language** | SQL | MongoDB Query API (JSON-like) |
| **Transactions** | Strong ACID support | ACID for multi-document transactions (since 4.0), but typically used less |
| **Best for** | Structured data, complex joins, banking/ERP | Semi-structured, rapidly changing, large-scale data (catalogs, IoT, CMS) |
