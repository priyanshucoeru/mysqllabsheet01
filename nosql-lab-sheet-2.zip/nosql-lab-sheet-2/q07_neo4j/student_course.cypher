// Run in Neo4j Browser (http://localhost:7474) or cypher-shell
// Docker: docker run -d --name neo4j -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password123 neo4j:5

// 1. Create 5 students and 3 courses
CREATE (:Student {id:101, name:'Amit Sharma'}),
       (:Student {id:102, name:'Priya Singh'}),
       (:Student {id:103, name:'Rahul Verma'}),
       (:Student {id:104, name:'Neha Gupta'}),
       (:Student {id:105, name:'Karan Mehta'});

CREATE (:Course {code:'C1', title:'Database Systems'}),
       (:Course {code:'C2', title:'Operating Systems'}),
       (:Course {code:'C3', title:'Python Programming'});

// ENROLLED_IN relationships
MATCH (s:Student {id:101}), (c:Course {code:'C1'}) CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:101}), (c:Course {code:'C3'}) CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:102}), (c:Course {code:'C1'}) CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:103}), (c:Course {code:'C2'}) CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:104}), (c:Course {code:'C2'}) CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:104}), (c:Course {code:'C3'}) CREATE (s)-[:ENROLLED_IN]->(c);
MATCH (s:Student {id:105}), (c:Course {code:'C1'}) CREATE (s)-[:ENROLLED_IN]->(c);

// 2. Display all students
MATCH (s:Student) RETURN s;

// 3. Students enrolled in a particular course
MATCH (s:Student)-[:ENROLLED_IN]->(c:Course {title:'Database Systems'})
RETURN s.name AS student;

// 4. All courses taken by a particular student
MATCH (s:Student {name:'Amit Sharma'})-[:ENROLLED_IN]->(c:Course)
RETURN c.title AS course;

// 5a. Add a relationship
MATCH (s:Student {id:103}), (c:Course {code:'C3'})
CREATE (s)-[:ENROLLED_IN]->(c);

// 5b. Remove a relationship
MATCH (s:Student {id:103})-[r:ENROLLED_IN]->(c:Course {code:'C3'})
DELETE r;

// View the whole graph
MATCH (s:Student)-[r:ENROLLED_IN]->(c:Course) RETURN s, r, c;
