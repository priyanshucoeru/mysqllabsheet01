# Q1 – Install & configure Riak KV (Linux)

## Option A – Docker (fastest, any OS)
```bash
docker run -d --name riak -p 8098:8098 -p 8087:8087 basho/riak-kv
sleep 30
curl http://localhost:8098/ping          # -> OK
docker exec riak riak-admin status | head
```
Ports: **8098** = HTTP API (used in all scripts), **8087** = Protocol Buffers.

## Option B – Native install on Linux (Ubuntu/Debian)
1. Download the latest Riak KV `.deb` package for your distro from the official Riak KV releases page
   (Riak KV is now maintained by TI Tokyo – https://github.com/basho/riak/releases and https://www.tiot.jp/riak-docs).
2. Install it:
   ```bash
   sudo dpkg -i riak_*.deb || sudo apt -f install -y
   ```
3. Raise the open-files limit (Riak needs many files):
   ```bash
   ulimit -n 65536        # also add "* soft nofile 65536" / "* hard nofile 65536" to /etc/security/limits.conf
   ```
4. Check `/etc/riak/riak.conf`, e.g.
   ```
   listener.http.internal = 0.0.0.0:8098
   storage_backend = bitcask
   ```
5. Start & verify:
   ```bash
   sudo riak start
   sudo riak ping            # pong
   sudo riak-admin status
   curl http://localhost:8098/ping
   ```
> Package names/versions change – follow the instructions on the page above if a command differs.

## Run the students demo
```bash
bash students.sh
```
