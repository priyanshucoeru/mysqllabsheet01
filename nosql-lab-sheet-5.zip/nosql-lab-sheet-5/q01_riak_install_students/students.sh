#!/bin/bash
# Key-value operations on bucket "students"   (bucket is created automatically on first write)
RIAK=${RIAK_URL:-http://localhost:8098}
B="$RIAK/buckets/students/keys"
JSON="Content-Type: application/json"

echo "== Is Riak alive? =="; curl -s $RIAK/ping; echo

echo; echo "== 1. STORE student records =="
curl -s -X PUT -H "$JSON" -d '{"id":101,"name":"Amit Sharma","course":"BCA","semester":3,"marks":78}' -w "HTTP %{http_code}\n" $B/101
curl -s -X PUT -H "$JSON" -d '{"id":102,"name":"Priya Singh","course":"BCA","semester":3,"marks":85}' -w "HTTP %{http_code}\n" $B/102
curl -s -X PUT -H "$JSON" -d '{"id":103,"name":"Rahul Verma","course":"MCA","semester":1,"marks":69}' -w "HTTP %{http_code}\n" $B/103
curl -s -X PUT -H "$JSON" -d '{"id":104,"name":"Neha Gupta","course":"BTech","semester":5,"marks":91}' -w "HTTP %{http_code}\n" $B/104
curl -s -X PUT -H "$JSON" -d '{"id":105,"name":"Karan Mehta","course":"MCA","semester":2,"marks":74}' -w "HTTP %{http_code}\n" $B/105

echo; echo "== 2. RETRIEVE student 102 =="
curl -s $B/102; echo

echo; echo "== 3. UPDATE student 102 (marks 85 -> 90) - PUT on same key overwrites the value =="
curl -s -X PUT -H "$JSON" -d '{"id":102,"name":"Priya Singh","course":"BCA","semester":3,"marks":90}' -w "HTTP %{http_code}\n" $B/102
curl -s $B/102; echo

echo; echo "== 4. DELETE student 105 =="
curl -s -X DELETE -w "HTTP %{http_code}\n" $B/105
curl -s -w "  <- HTTP %{http_code} (404 = not found)\n" $B/105

echo; echo "== 5. LIST all keys in the bucket =="
curl -s "$RIAK/buckets/students/keys?keys=true"; echo
