# Query-by-data in Riak

A pure key-value store retrieves values **only by key**. To "find users in Roorkee" you can:

1. **Application-level scan (demo steps 2–5):** list keys, GET each value, filter in code. Simple, but O(n) – listing keys is expensive and not recommended on large production buckets.
2. **Manual index (demo step 6):** keep an extra bucket (`users_by_city`) mapping attribute → list of keys. Lookup is O(1); the app must keep it in sync (no automatic update, no transaction).
3. **Riak built-in options (need configuration):**
   - **Secondary Indexes (2i)** – add `x-riak-index-city_bin: Roorkee` header on PUT, query `/buckets/users/index/city_bin/Roorkee` (requires LevelDB/Memory backend, not default Bitcask).
   - **Riak Search (Solr / Yokozuna)** – full-text and field queries on JSON.
