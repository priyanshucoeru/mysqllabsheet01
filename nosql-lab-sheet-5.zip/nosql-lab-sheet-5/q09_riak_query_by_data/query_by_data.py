"""Query-by-data in Riak using application-level logic.  Run: python3 query_by_data.py
A key-value store can only look up by KEY, so we (1) scan + filter in the app, or (2) maintain our own index."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "riak_common"))
import riak_http as riak

USERS = {
    "U1": {"name": "Amit Sharma",  "city": "Roorkee",  "age": 21, "preferences": ["music", "cricket"]},
    "U2": {"name": "Priya Singh",  "city": "Delhi",    "age": 24, "preferences": ["travel", "music"]},
    "U3": {"name": "Rahul Verma",  "city": "Roorkee",  "age": 30, "preferences": ["gaming"]},
    "U4": {"name": "Neha Gupta",   "city": "Dehradun", "age": 22, "preferences": ["music", "reading"]},
    "U5": {"name": "Karan Mehta",  "city": "Delhi",    "age": 35, "preferences": ["cricket", "travel"]},
    "U6": {"name": "Sana Khan",    "city": "Roorkee",  "age": 19, "preferences": ["reading"]},
}

riak.title("1. Store user JSON documents")
for uid, doc in USERS.items():
    print(uid, "-> HTTP", riak.put("users_q", uid, doc))


def find_users(predicate):
    """Application-level query: list all keys, fetch each value, filter locally (full scan)."""
    result = []
    for key in riak.keys("users_q"):
        doc = riak.get("users_q", key)["value"]
        if doc and predicate(doc):
            result.append((key, doc["name"]))
    return sorted(result)


riak.title("2. Users in Roorkee (scan + filter)")
print(find_users(lambda u: u["city"] == "Roorkee"))

riak.title("3. Users aged 21-30")
print(find_users(lambda u: 21 <= u["age"] <= 30))

riak.title("4. Users who like 'music'")
print(find_users(lambda u: "music" in u["preferences"]))

riak.title("5. Combined: city = Delhi AND likes travel")
print(find_users(lambda u: u["city"] == "Delhi" and "travel" in u["preferences"]))

# ---- Better: build our own secondary index (inverted index) as extra key-value pairs ----
riak.title("6. Manual index bucket 'users_by_city'  (key = city, value = list of user ids)")
index = {}
for uid, doc in USERS.items():
    index.setdefault(doc["city"], []).append(uid)
for city, ids in index.items():
    riak.put("users_by_city", city, ids)

def users_in_city_indexed(city):
    r = riak.get("users_by_city", city)           # ONE key lookup instead of scanning every user
    return r["value"] if r["status"] == 200 else []

print("Roorkee ->", users_in_city_indexed("Roorkee"))
print("Delhi   ->", users_in_city_indexed("Delhi"))
print("(index must be updated by the app whenever a user's city changes)")
