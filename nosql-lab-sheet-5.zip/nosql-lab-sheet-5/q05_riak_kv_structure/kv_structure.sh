#!/bin/bash
# Different value types in bucket "kv_demo". Riak does not care about the type: a value is just bytes + a Content-Type.
RIAK=${RIAK_URL:-http://localhost:8098}
B="$RIAK/buckets/kv_demo/keys"

echo "== 1. STRING value (text/plain) =="
curl -s -X PUT -H "Content-Type: text/plain" -d 'Hello NoSQL' -w "HTTP %{http_code}\n" $B/greeting
curl -si $B/greeting | grep -iE "^(HTTP|content-type)|Hello"; echo

echo "== 2. NUMBER stored as text =="
curl -s -X PUT -H "Content-Type: text/plain" -d '42' -w "HTTP %{http_code}\n" $B/answer
curl -s $B/answer; echo

echo; echo "== 3. JSON document (application/json) =="
curl -s -X PUT -H "Content-Type: application/json" -w "HTTP %{http_code}\n" $B/student:101 \
  -d '{"id":101,"name":"Amit","skills":["Python","SQL"],"address":{"city":"Roorkee","pin":247667}}'
curl -si $B/student:101 | grep -iE "^(HTTP|content-type)|\{"; echo

echo; echo "== 4. LIST (stored as a JSON array) =="
curl -s -X PUT -H "Content-Type: application/json" -w "HTTP %{http_code}\n" $B/fruits -d '["apple","banana","mango","orange"]'
curl -s $B/fruits; echo

echo; echo "== 5. Keys in the bucket =="
curl -s "$RIAK/buckets/kv_demo/keys?keys=true"; echo

echo; echo "== 6. Same key, different bucket = different value (buckets are namespaces) =="
curl -s -X PUT -H "Content-Type: text/plain" -d 'value in OTHER bucket' $RIAK/buckets/other_bucket/keys/greeting
curl -s $RIAK/buckets/other_bucket/keys/greeting; echo
curl -s $B/greeting; echo
