# Structure of a key-value store (Riak)

```
 Bucket  ──►  Key  ──►  Value
 "kv_demo"    "fruits"   ["apple","banana","mango","orange"]
```
| Part | Role |
|---|---|
| **Bucket** | A namespace / logical container for keys (like a table, but with no schema). Per-bucket properties: `n_val` (replicas), `r`, `w`, `allow_mult`, backend. The same key can exist in different buckets. |
| **Key** | Unique identifier inside a bucket. It is the **only way to look up** a value; Riak hashes `bucket+key` (SHA-1) to decide which nodes store it. |
| **Value** | The data: an opaque blob (string, JSON, list, image…). Riak does not look inside it; the **Content-Type** header tells clients how to interpret it. |

Notes from the demo
- String, number, JSON and list values are all stored the same way – as bytes with a content type.
- To change *part* of a value (e.g. one JSON field) the application must GET the whole value, modify it and PUT it back.
- `GET` by key is O(1) and very fast; searching by value requires application logic, an index (2i) or Riak Search.
