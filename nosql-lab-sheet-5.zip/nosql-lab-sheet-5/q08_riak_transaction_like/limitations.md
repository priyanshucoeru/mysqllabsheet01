# Transactions in a key-value database – limitations

What Riak guarantees: an update to **one key** is atomic (readers see the old or the new value, never half).

| Limitation | Effect in the shopping demo |
|---|---|
| **No multi-key ACID transactions** | Updating cart, total and inventory = 3+ separate writes; a crash in between leaves inconsistent data (scenario B). |
| **No rollback** | The application must undo earlier steps itself (compensating actions, scenario C) or use the Saga pattern. |
| **No isolation** | Another client can read the cart between step 1 and step 3 and see a half-finished state. |
| **No locks / joins** | Cannot lock the cart or inventory row; no foreign-key or constraint checking. |
| **Concurrent writers** | Without a version check the *last write wins* and silently overwrites; with `allow_mult` you get siblings to merge (scenario D). |
| **Eventual consistency** | Replicas may briefly disagree unless R + W > N. |

**Design workarounds**
- Put everything that must change together **in one object** (e.g. the cart JSON contains items *and* total) → one atomic PUT.
- Write in a safe order, make operations **idempotent**, and keep a status field (`pending → confirmed`).
- Use vector clocks / ETags for optimistic concurrency; resolve siblings in the application.
- Use a SQL / strongly-consistent store (or Riak KV strong-consistency buckets) when real ACID multi-record transactions are required (payments, banking).
