"""Transaction-like scenario in Riak KV (shopping app).  Run: python3 transaction_like.py
Riak has NO multi-key transactions: each PUT is atomic only for ONE key.
We emulate a transaction with ordered steps, a version check (vector clock) and compensation."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "riak_common"))
import riak_http as riak


def reset():
    for b, k in [("carts", "U1"), ("inventory", "P101"), ("orders", "ORD-1")]:
        riak.delete(b, k)
    riak.put("inventory", "P101", {"product": "Laptop Bag", "stock": 10})
    riak.put("carts", "U1", {"user_id": "U1", "items": [], "total": 0})


def checkout_steps(fail_after=None):
    """Steps: 1) add item to cart  2) update its quantity  3) update cart total  4) reduce stock"""
    cart_r = riak.get("carts", "U1")
    cart, vc = cart_r["value"], cart_r["vclock"]

    cart["items"].append({"product_id": "P101", "qty": 1, "price": 1500})
    riak.put("carts", "U1", cart, vclock=vc);                       print("step 1: item added to cart")
    if fail_after == 1: raise RuntimeError("crash after step 1")

    cart_r = riak.get("carts", "U1"); cart, vc = cart_r["value"], cart_r["vclock"]
    cart["items"][0]["qty"] = 3
    riak.put("carts", "U1", cart, vclock=vc);                       print("step 2: quantity updated to 3")
    if fail_after == 2: raise RuntimeError("crash after step 2")

    cart_r = riak.get("carts", "U1"); cart, vc = cart_r["value"], cart_r["vclock"]
    cart["total"] = sum(i["qty"] * i["price"] for i in cart["items"])
    riak.put("carts", "U1", cart, vclock=vc);                       print("step 3: cart total updated =", cart["total"])
    if fail_after == 3: raise RuntimeError("crash after step 3")

    inv_r = riak.get("inventory", "P101"); inv, ivc = inv_r["value"], inv_r["vclock"]
    inv["stock"] -= 3
    riak.put("inventory", "P101", inv, vclock=ivc);                 print("step 4: stock reduced to", inv["stock"])


def show():
    print("   cart     :", riak.get("carts", "U1")["value"])
    print("   inventory:", riak.get("inventory", "P101")["value"])


riak.title("A. Normal run - all 4 steps succeed")
reset(); checkout_steps(); show()

riak.title("B. Failure after step 3 - NO automatic rollback (cart changed, stock NOT)")
reset()
try:
    checkout_steps(fail_after=3)
except RuntimeError as e:
    print("!!", e)
show()
print("   -> data is now INCONSISTENT: cart says 3 items, inventory still 10")

riak.title("C. Compensating action (application-level 'rollback')")
riak.put("carts", "U1", {"user_id": "U1", "items": [], "total": 0}, vclock=riak.get("carts", "U1")["vclock"])
print("cart cleared by compensation"); show()

riak.title("D. Concurrent update conflict (two clients edit the same cart)")
riak.set_props("carts_conflict", {"allow_mult": True, "last_write_wins": False})
riak.delete("carts_conflict", "U1")
riak.put("carts_conflict", "U1", {"items": ["base"]})
base = riak.get("carts_conflict", "U1")["vclock"]
riak.put("carts_conflict", "U1", {"items": ["base", "added by client A"]}, vclock=base)
riak.put("carts_conflict", "U1", {"items": ["base", "added by client B"]}, vclock=base)   # same ancestor => sibling
r = riak.get("carts_conflict", "U1")
print("HTTP status:", r["status"], "(300 = siblings, application must merge)")
print(r["value"][:400] if r["value"] else "")
