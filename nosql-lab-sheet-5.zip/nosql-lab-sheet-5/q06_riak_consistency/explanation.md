# How Riak handles consistency

Riak is a **Dynamo-style, masterless** store (AP in CAP, tunable towards C).

| Setting | Meaning |
|---|---|
| **N** (`n_val`) | Number of replicas of every object (default 3). |
| **W** | Replicas that must acknowledge a write before it is reported successful. |
| **R** | Replicas that must answer a read before the result is returned. |
| `quorum` | `floor(N/2)+1` = 2 when N=3. |

**Rule:** if **R + W > N** (e.g. 2 + 2 > 3) every read quorum overlaps the last write quorum → the read sees the latest write ("strong-ish" consistency).
- `R=1, W=1` → fastest, highest availability, may read stale data (eventual consistency).
- `R=quorum, W=quorum` → balanced, tolerates 1 failed node.
- `W=all` → every replica must be up, strongest durability, least available.

**In a distributed environment**
1. A write is sent to the N replicas (vnodes) of the key's partition; any node can coordinate it.
2. When replicas diverge (network partition, concurrent clients) Riak does **not** reject writes. It tracks history with **vector clocks / dotted version vectors** and either keeps **siblings** (`allow_mult=true`) or picks the newest timestamp (`last_write_wins=true`).
3. **Read repair** fixes stale replicas when they are read; **hinted handoff** stores writes for a down node on a stand-in node and hands them back later; **Active Anti-Entropy** (Merkle trees) repairs silently in the background.
4. Applications resolve siblings (merge) – demonstrated in step 4–5 of `consistency.sh`.

*Note:* with the single-node Docker setup the 3 replicas live on vnodes of the same node, but quorum logic and siblings behave the same.
