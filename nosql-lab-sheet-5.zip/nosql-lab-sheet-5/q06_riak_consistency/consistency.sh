#!/bin/bash
# Consistency in Riak: N (replicas), R (read quorum), W (write quorum)
RIAK=${RIAK_URL:-http://localhost:8098}
JSON="Content-Type: application/json"

echo "== 1. Configure bucket 'accounts': N=3 replicas, R=2, W=2 (quorum) =="
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $RIAK/buckets/accounts/props \
  -d '{"props":{"n_val":3,"r":2,"w":2}}'
echo "Bucket properties now:"
curl -s $RIAK/buckets/accounts/props | tr ',' '\n' | grep -E '"(n_val|r|w|dw|allow_mult)"'

K="$RIAK/buckets/accounts/keys/acc1"
echo; echo "== 2. WRITE with different write quorums (per-request override: ?w=) =="
curl -s -X PUT -H "$JSON" -w "w=1      -> HTTP %{http_code}\n" "$K?w=1"      -d '{"owner":"Amit","balance":1000}'
curl -s -X PUT -H "$JSON" -w "w=quorum -> HTTP %{http_code}\n" "$K?w=quorum" -d '{"owner":"Amit","balance":1500}'
curl -s -X PUT -H "$JSON" -w "w=all    -> HTTP %{http_code}\n" "$K?w=all"    -d '{"owner":"Amit","balance":2000}'

echo; echo "== 3. READ with different read quorums (?r=) =="
echo -n "r=1      : "; curl -s "$K?r=1"; echo
echo -n "r=quorum : "; curl -s "$K?r=quorum"; echo
echo -n "r=all    : "; curl -s "$K?r=all"; echo

echo; echo "== 4. Conflicting writes (allow_mult=true keeps BOTH versions as siblings) =="
curl -s -X PUT -H "$JSON" $RIAK/buckets/conflict_demo/props -d '{"props":{"allow_mult":true,"last_write_wins":false}}'
C="$RIAK/buckets/conflict_demo/keys/doc1"
curl -s -X DELETE $C
curl -s -X PUT -H "Content-Type: text/plain" -d 'version written by client A' $C
curl -s -X PUT -H "Content-Type: text/plain" -d 'version written by client B' $C     # no vector clock => concurrent
echo "--- GET shows siblings (HTTP 300 = Multiple Choices) ---"
curl -si -H "Accept: multipart/mixed" $C | tr -d '\r' | grep -vE "^(Server|Date|Content-Length|Link)"

echo; echo "== 5. Resolve the conflict: read the vector clock, write merged value with it =="
VC=$(curl -si -H "Accept: multipart/mixed" $C | tr -d '\r' | grep -i '^X-Riak-Vclock' | awk '{print $2}')
echo "Vector clock: $VC"
curl -s -X PUT -H "Content-Type: text/plain" -H "X-Riak-Vclock: $VC" -d 'merged value (A + B)' -w "HTTP %{http_code}\n" $C
curl -si $C | tr -d '\r' | tail -2
