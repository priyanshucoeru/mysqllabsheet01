#!/bin/bash
# Create 3 buckets and insert 300 records into each (900 key-value pairs)
RIAK=${RIAK_URL:-http://localhost:8098}
JSON="Content-Type: application/json"
N=${1:-300}

echo "Inserting $N records into each of: users, products, orders ..."
for i in $(seq 1 $N); do
  curl -s -o /dev/null -X PUT -H "$JSON" $RIAK/buckets/users/keys/user_$i    -d "{\"id\":$i,\"name\":\"User$i\",\"city\":\"City$((i % 10))\"}"
  curl -s -o /dev/null -X PUT -H "$JSON" $RIAK/buckets/products/keys/prod_$i -d "{\"id\":$i,\"name\":\"Product$i\",\"price\":$((100 + i))}"
  curl -s -o /dev/null -X PUT -H "$JSON" $RIAK/buckets/orders/keys/order_$i  -d "{\"id\":$i,\"user\":\"user_$i\",\"product\":\"prod_$i\",\"qty\":$((i % 5 + 1))}"
  [ $((i % 100)) -eq 0 ] && echo "  ... $i done"
done

echo; echo "== Number of keys per bucket =="
for b in users products orders; do
  c=$(curl -s "$RIAK/buckets/$b/keys?keys=true" | grep -oE '"[a-z]+_[0-9]+"' | sort -u | wc -l)
  echo "$b: $c keys"
done

echo; echo "== Sample reads (O(1) lookup by key) =="
curl -s $RIAK/buckets/users/keys/user_150; echo
curl -s $RIAK/buckets/products/keys/prod_299; echo
curl -s $RIAK/buckets/orders/keys/order_7; echo

echo; echo "== Ring / partition info =="
echo "Run these inside the node:"
echo "  docker exec riak riak-admin ring-status"
echo "  docker exec riak riak-admin member-status"
echo "  docker exec riak riak-admin ring-status | head -30"
