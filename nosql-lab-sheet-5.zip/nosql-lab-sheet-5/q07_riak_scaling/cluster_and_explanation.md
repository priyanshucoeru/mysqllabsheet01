# Q7 – Scaling in Riak

## Run
```bash
bash seed_data.sh          # or: bash seed_data.sh 1000
```

## Optional: grow to a 2-node cluster (shows horizontal scaling)
```bash
docker network create riaknet
docker run -d --name riak1 --network riaknet -p 8098:8098 basho/riak-kv
docker run -d --name riak2 --network riaknet basho/riak-kv
sleep 40
# node names look like riak@<container-ip>; check with:  docker exec riak1 riak-admin status | grep nodename
IP1=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' riak1)
docker exec riak2 riak-admin cluster join riak@$IP1
docker exec riak2 riak-admin cluster plan
docker exec riak2 riak-admin cluster commit
docker exec riak1 riak-admin member-status     # shows ring ownership % of each node (~50/50)
docker exec riak1 riak-admin transfers         # partitions moving to the new node
```
Re-run the "Sample reads" from `seed_data.sh` – the data is still available while the ring rebalances.

## How Riak distributes data
```
   hash(bucket+key) = SHA-1  ─►  position on a 160-bit ring
   Ring split into 64 equal PARTITIONS (vnodes) by default

   Node A: p1 p4 p7 ...      Node B: p2 p5 p8 ...      Node C: p3 p6 p9 ...
   key "user_150" -> partition p5 (primary) + the next N-1 partitions (replicas, on other nodes)
```
1. **Consistent hashing** spreads keys uniformly – no hot spots, no shard key to choose.
2. Each key is stored on **N=3** consecutive partitions that belong to different nodes → copies on different machines.
3. **Masterless:** every node can receive any request and routes it to the right partitions → no single point of failure or bottleneck.
4. **Adding a node:** the new node *takes over some partitions* from existing nodes (only ~1/(n+1) of data moves). Capacity and throughput grow roughly linearly.
5. **Removing / failed node:** its partitions' replicas on other nodes keep serving; hinted handoff + anti-entropy repair later.
6. Multiple buckets share the same ring; bucket properties (N, R, W, backend) can differ per bucket.
