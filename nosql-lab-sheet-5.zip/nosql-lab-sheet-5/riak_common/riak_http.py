"""Tiny Riak KV HTTP client (standard library only - no pip install needed).
Riak HTTP API:  /buckets/<bucket>/keys/<key>
Set RIAK_URL if Riak is not on http://localhost:8098"""
import json
import os
import urllib.error
import urllib.request

BASE = os.environ.get("RIAK_URL", "http://localhost:8098")


def _request(method, path, data=None, headers=None):
    h = dict(headers or {})
    body = None
    if data is not None:
        if isinstance(data, (dict, list)):
            body = json.dumps(data).encode()
            h.setdefault("Content-Type", "application/json")
        elif isinstance(data, str):
            body = data.encode()
            h.setdefault("Content-Type", "text/plain")
        else:
            body = data
    req = urllib.request.Request(BASE + path, data=body, method=method, headers=h)
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, {k.lower(): v for k, v in r.headers.items()}, r.read()
    except urllib.error.HTTPError as e:
        return e.code, {k.lower(): v for k, v in e.headers.items()}, e.read()


def _query(params):
    return "?" + "&".join(f"{k}={v}" for k, v in params.items()) if params else ""


def put(bucket, key, value, params=None, vclock=None):
    """Store a value (dict/list -> JSON, str -> text). Returns HTTP status."""
    headers = {"X-Riak-Vclock": vclock} if vclock else {}
    status, _, _ = _request("PUT", f"/buckets/{bucket}/keys/{key}{_query(params)}", value, headers)
    return status


def get(bucket, key, params=None):
    """Returns dict: status, value, vclock, content_type. status 404 = not found, 300 = siblings."""
    status, h, body = _request("GET", f"/buckets/{bucket}/keys/{key}{_query(params)}",
                               headers={"Accept": "multipart/mixed"})
    ctype = h.get("content-type", "")
    value = None
    if status == 200:
        text = body.decode(errors="replace")
        value = json.loads(text) if "json" in ctype else text
    elif status == 300:
        value = body.decode(errors="replace")
    return {"status": status, "value": value, "vclock": h.get("x-riak-vclock"), "content_type": ctype}


def delete(bucket, key):
    status, _, _ = _request("DELETE", f"/buckets/{bucket}/keys/{key}")
    return status


def keys(bucket):
    status, _, body = _request("GET", f"/buckets/{bucket}/keys?keys=true")
    return json.loads(body)["keys"] if status == 200 else []


def set_props(bucket, props):
    return _request("PUT", f"/buckets/{bucket}/props", {"props": props})[0]


def get_props(bucket):
    return json.loads(_request("GET", f"/buckets/{bucket}/props")[2])["props"]


def raw(method, path, data=None, headers=None):
    return _request(method, path, data, headers)


def title(text):
    print("\n" + "=" * 8, text, "=" * 8)
