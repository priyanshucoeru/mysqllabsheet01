# Graph databases – relationship queries, scaling, availability, use cases

## Relationship-based queries
Relationships are stored as first-class records with direct pointers (**index-free adjacency**). Following a relationship costs the same no matter how large the database is, so multi-hop queries stay fast:
- friends / friends-of-friends (`(a)-[:FRIENDS_WITH]-()-[:FRIENDS_WITH]-(b)`)
- shortest path (`shortestPath`)
- fraud rings (accounts that share a phone/device)
In SQL the same queries need many self-JOINs whose cost grows with table size.

## Scaling
- **Vertical:** a single Neo4j server handles billions of nodes/relationships.
- **Read scaling:** cluster with **secondary** servers replicating from **primaries**.
- **Large graphs:** Neo4j *Infinigraph* / property sharding and Fabric (Enterprise) can split a graph across databases. Graph partitioning is inherently harder than for key-value or document stores (relationships cross shard boundaries).

## Availability
Cluster with Raft-based **primary** servers: if the leader fails, a new leader is elected; clients use `neo4j://` routing driver to reconnect. Backups and causal clustering give disaster recovery.

## Suitable use cases
| Use case | Why a graph fits |
|---|---|
| **Social networks** | friends, followers, mutual connections, communities |
| **Recommendation systems** | "people who bought X also bought Y" through shared relationships |
| **Fraud detection** | detect rings sharing identities, phones, devices, addresses in real time |
| **Knowledge graphs** | linked entities (people, places, concepts) with typed relations |
| Others | network/IT topology, supply chain, access control, route planning |

## Not ideal for
Heavy aggregate analytics over all rows, simple key lookups, or data with few relationships (use SQL / key-value / document stores).
