"""Small Graph Database application: Social network + recommendations + fraud detection
Neo4j + Python.

Setup:   pip install -r requirements.txt
         docker run -d --name neo4j -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password123 neo4j:5
Run:     python3 graph_app.py
Env vars (optional): NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD
"""
import os
from neo4j import GraphDatabase

URI = os.environ.get("NEO4J_URI", "bolt://localhost:7687")
USER = os.environ.get("NEO4J_USER", "neo4j")
PASSWORD = os.environ.get("NEO4J_PASSWORD", "password123")


class GraphApp:
    def __init__(self):
        self.driver = GraphDatabase.driver(URI, auth=(USER, PASSWORD))
        self.driver.verify_connectivity()

    def close(self):
        self.driver.close()

    def run(self, query, **params):
        """Run a query in its own (auto-commit) transaction and return list of dicts."""
        with self.driver.session() as session:
            return [r.data() for r in session.run(query, **params)]

    # ------------------------------------------------------------------ CRUD
    def setup(self):
        self.run("MATCH (n) DETACH DELETE n")
        self.run("CREATE CONSTRAINT person_email IF NOT EXISTS FOR (p:Person) REQUIRE p.email IS UNIQUE")

    def create_person(self, name, email, city, age):                       # C
        return self.run("MERGE (p:Person {email:$email}) "
                        "SET p.name=$name, p.city=$city, p.age=$age RETURN p.name AS name",
                        name=name, email=email, city=city, age=age)

    def get_person(self, name):                                            # R
        return self.run("MATCH (p:Person {name:$name}) RETURN properties(p) AS person", name=name)

    def update_person(self, name, **props):                                # U
        return self.run("MATCH (p:Person {name:$name}) SET p += $props RETURN properties(p) AS person",
                        name=name, props=props)

    def delete_person(self, name):                                         # D (DETACH removes its relationships too)
        return self.run("MATCH (p:Person {name:$name}) DETACH DELETE p", name=name)

    # --------------------------------------------------------- relationships
    def add_friend(self, a, b):
        self.run("MATCH (x:Person {name:$a}), (y:Person {name:$b}) MERGE (x)-[:FRIENDS_WITH]->(y)", a=a, b=b)

    def follow(self, a, b):
        self.run("MATCH (x:Person {name:$a}), (y:Person {name:$b}) MERGE (x)-[:FOLLOWS]->(y)", a=a, b=b)

    # ------------------------------------------------- relationship queries
    def friends(self, name):
        return [r["friend"] for r in self.run(
            "MATCH (:Person {name:$n})-[:FRIENDS_WITH]-(f) RETURN f.name AS friend ORDER BY friend", n=name)]

    def followers(self, name):
        return [r["f"] for r in self.run(
            "MATCH (f:Person)-[:FOLLOWS]->(:Person {name:$n}) RETURN f.name AS f ORDER BY f", n=name)]

    def recommend_friends(self, name):
        """Friend-of-friend recommendation ranked by number of mutual friends."""
        return self.run("""
            MATCH (me:Person {name:$n})-[:FRIENDS_WITH]-(m)-[:FRIENDS_WITH]-(rec:Person)
            WHERE rec <> me AND NOT (me)-[:FRIENDS_WITH]-(rec)
            RETURN rec.name AS suggestion, count(DISTINCT m) AS mutual_friends
            ORDER BY mutual_friends DESC, suggestion""", n=name)

    def shortest_path(self, a, b):
        res = self.run("""
            MATCH p = shortestPath((:Person {name:$a})-[:FRIENDS_WITH*..6]-(:Person {name:$b}))
            RETURN [n IN nodes(p) | n.name] AS path""", a=a, b=b)
        return res[0]["path"] if res else None

    # --------------------------------------------------------- fraud demo
    def load_fraud_demo(self):
        self.run("""
            CREATE (a1:Account {id:'A1', holder:'Amit'}),  (a2:Account {id:'A2', holder:'Ravi'}),
                   (a3:Account {id:'A3', holder:'Sita'}),  (a4:Account {id:'A4', holder:'Vijay'}),
                   (ph:Phone {number:'9000000000'}),  (dv:Device {id:'DEV-77'}),
                   (a1)-[:USES]->(ph), (a2)-[:USES]->(ph),          // two "different" people share a phone
                   (a2)-[:USES]->(dv), (a3)-[:USES]->(dv),          // ... and a device
                   (a4)-[:USES]->(:Phone {number:'9111111111'})""")

    def suspicious_rings(self):
        """Accounts that share a phone/device with other accounts = possible fraud ring."""
        return self.run("""
            MATCH (a:Account)-[:USES]->(x)<-[:USES]-(b:Account) WHERE a.id < b.id
            RETURN a.holder AS account1, b.holder AS account2, labels(x)[0] AS shared_item""")


def show(title, value):
    print(f"\n--- {title} ---")
    print(value)


if __name__ == "__main__":
    app = GraphApp()
    app.setup()

    # CRUD
    for n, e, c, a in [("Amit", "amit@mail.com", "Roorkee", 21), ("Priya", "priya@mail.com", "Delhi", 24),
                       ("Rahul", "rahul@mail.com", "Dehradun", 30), ("Neha", "neha@mail.com", "Roorkee", 22),
                       ("Karan", "karan@mail.com", "Delhi", 35), ("Sana", "sana@mail.com", "Mumbai", 28)]:
        app.create_person(n, e, c, a)
    show("READ person Amit", app.get_person("Amit"))
    show("UPDATE Amit (age 22, city Delhi)", app.update_person("Amit", age=22, city="Delhi"))
    app.create_person("Temp", "temp@mail.com", "X", 1)
    app.delete_person("Temp")
    show("DELETE Temp -> exists?", app.get_person("Temp") != [])

    # relationships
    for a, b in [("Amit", "Priya"), ("Amit", "Rahul"), ("Priya", "Neha"), ("Rahul", "Karan"),
                 ("Neha", "Sana"), ("Karan", "Sana")]:
        app.add_friend(a, b)
    for a, b in [("Amit", "Karan"), ("Priya", "Karan"), ("Rahul", "Karan"), ("Neha", "Sana")]:
        app.follow(a, b)

    # relationship-based queries
    show("Friends of Amit", app.friends("Amit"))
    show("Followers of Karan", app.followers("Karan"))
    show("Friend recommendations for Amit", app.recommend_friends("Amit"))
    show("Shortest friendship path Amit -> Sana", app.shortest_path("Amit", "Sana"))

    # fraud detection
    app.load_fraud_demo()
    show("Possible fraud rings (shared phone/device)", app.suspicious_rings())

    app.close()
