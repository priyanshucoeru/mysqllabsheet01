# BCA305P – NoSQL Database Design: Lab Sheet 5 (Riak KV & Neo4j)

**Name:** ______________  **Roll No:** ______________

| Q | Topic | Folder |
|---|---|---|
| 1 | Install Riak, `students` bucket | `q01_riak_install_students` |
| 2 | `user_sessions` bucket | `q02_riak_user_sessions` |
| 3 | User profiles & preferences | `q03_riak_profiles` |
| 4 | Shopping cart | `q04_riak_shopping_cart` |
| 5 | Structure of a key-value store | `q05_riak_kv_structure` |
| 6 | Consistency (N, R, W) | `q06_riak_consistency` |
| 7 | Scaling | `q07_riak_scaling` |
| 8 | Transaction-like scenario | `q08_riak_transaction_like` |
| 9 | Query-by-data | `q09_riak_query_by_data` |
| 10 | Set operations | `q10_riak_sets` |
| 11 | Install Neo4j, Student/Course/Department graph | `q11_neo4j_install_university` |
| 12 | Social network | `q12_neo4j_social_network` |
| 13 | E-commerce graph | `q13_neo4j_ecommerce` |
| 14 | Transactions, consistency, availability | `q14_neo4j_transactions` |
| 15 | Python + Neo4j application | `q15_neo4j_python_app` |

`riak_common/riak_http.py` is a small helper used by the Python scripts of Q4, Q8, Q9, Q10 (no pip install needed).

## Riak (Q1–Q10)
```bash
docker run -d --name riak -p 8098:8098 -p 8087:8087 basho/riak-kv
sleep 30 && curl http://localhost:8098/ping         # OK
bash q01_riak_install_students/students.sh          # bash/curl scripts (Linux, macOS, WSL, Git Bash)
python3 q04_riak_shopping_cart/cart_app.py          # Python 3 scripts
```
Q10 first needs `bash q10_riak_sets/setup_bucket_type.sh` (creates a `sets` bucket type).

## Neo4j (Q11–Q15)
```bash
docker run -d --name neo4j -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=neo4j/password123 neo4j:5
docker exec -i neo4j cypher-shell -u neo4j -p password123 < q12_neo4j_social_network/social_network.cypher
# or paste into the Neo4j Browser at http://localhost:7474 (needed for the graph visualisation screenshots)
pip install -r q15_neo4j_python_app/requirements.txt
python3 q15_neo4j_python_app/graph_app.py
```

## Upload to GitHub
```bash
git init && git add . && git commit -m "Add NoSQL Lab Sheet 5"
git branch -M main
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```
