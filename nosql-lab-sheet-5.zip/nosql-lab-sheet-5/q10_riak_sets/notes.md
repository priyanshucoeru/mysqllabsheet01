# Sets in Riak

Riak supports **CRDT data types**: counters, **sets**, maps, flags, registers (Riak 2.0+). A set:
- supports **add / remove** operations merged automatically (no siblings to resolve) – concurrent adds from different clients are all kept;
- needs a **bucket type** with `datatype = set` (see `setup_bucket_type.sh`);
- `remove` needs the *context* from a previous read (so Riak knows which adds are being removed).

Riak itself provides add/remove/read; **membership test and intersection** are done in the client on the returned set (`in`, `&`).

If you cannot create a bucket type, a fallback is to store the set as a JSON list under a normal key and update it with GET → modify → PUT (but concurrent updates may conflict).
