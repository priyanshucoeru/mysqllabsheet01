#!/bin/bash
# Riak sets are a CRDT data type -> need a bucket type with datatype=set (run ONCE, on a Riak node)
# Docker:   docker exec riak ...      Native:  run the riak-admin commands directly
docker exec riak riak-admin bucket-type create sets '{"props":{"datatype":"set"}}'
docker exec riak riak-admin bucket-type activate sets
docker exec riak riak-admin bucket-type status sets
