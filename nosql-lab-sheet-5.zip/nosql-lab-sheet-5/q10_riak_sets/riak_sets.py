"""Set operations with Riak's set data type (CRDT).  Run: bash setup_bucket_type.sh   then   python3 riak_sets.py
HTTP API: /types/<type>/buckets/<bucket>/datatypes/<key>"""
import json, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "riak_common"))
import riak_http as riak

TYPE, BUCKET = "sets", "interests"


def path(user):
    return f"/types/{TYPE}/buckets/{BUCKET}/datatypes/{user}"


def update(user, op):
    status, _, body = riak.raw("POST", path(user), op)
    return status


def fetch(user):
    status, _, body = riak.raw("GET", path(user))
    if status != 200:
        return set(), None
    d = json.loads(body)
    return set(d.get("value", [])), d.get("context")


riak.title("1. Create sets (add elements)")
update("amit",  {"add_all": ["music", "cricket", "travel"]})
update("priya", {"add_all": ["music", "reading", "travel", "yoga"]})
print("amit :", sorted(fetch("amit")[0]))
print("priya:", sorted(fetch("priya")[0]))

riak.title("2. Add one more element")
update("amit", {"add": "gaming"})
print("amit :", sorted(fetch("amit")[0]))

riak.title("3. Remove an element (needs the causal context returned by GET)")
members, ctx = fetch("amit")
update("amit", {"remove": "cricket", "context": ctx})
print("amit :", sorted(fetch("amit")[0]))

riak.title("4. Membership check")
amit = fetch("amit")[0]
print("'music' in amit's interests   ->", "music" in amit)
print("'cricket' in amit's interests ->", "cricket" in amit)

riak.title("5. Common elements (intersection) / union / difference - computed in the application")
priya = fetch("priya")[0]
print("common (amit & priya) :", sorted(amit & priya))
print("union                 :", sorted(amit | priya))
print("only amit             :", sorted(amit - priya))

riak.title("6. Set size")
print("amit has", len(amit), "interests")
