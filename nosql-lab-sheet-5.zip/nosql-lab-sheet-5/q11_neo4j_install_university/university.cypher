// Student, Course, Department graph
MATCH (n) DETACH DELETE n;

// Departments
CREATE (:Department {code:'CS',   name:'Computer Science'}),
       (:Department {code:'MATH', name:'Mathematics'});

// Courses (each offered by a department)
CREATE (:Course {code:'C1', title:'Database Systems'}),
       (:Course {code:'C2', title:'Operating Systems'}),
       (:Course {code:'C3', title:'Python Programming'}),
       (:Course {code:'C4', title:'Discrete Mathematics'});

MATCH (d:Department {code:'CS'}),   (c:Course) WHERE c.code IN ['C1','C2','C3'] CREATE (d)-[:OFFERS]->(c);
MATCH (d:Department {code:'MATH'}), (c:Course {code:'C4'})                      CREATE (d)-[:OFFERS]->(c);

// Students
CREATE (:Student {id:101, name:'Amit Sharma',  semester:3}),
       (:Student {id:102, name:'Priya Singh',  semester:3}),
       (:Student {id:103, name:'Rahul Verma',  semester:5}),
       (:Student {id:104, name:'Neha Gupta',   semester:5}),
       (:Student {id:105, name:'Karan Mehta',  semester:1});

// Student -> Department
MATCH (s:Student), (d:Department {code:'CS'})   WHERE s.id IN [101,102,103,104] CREATE (s)-[:BELONGS_TO]->(d);
MATCH (s:Student), (d:Department {code:'MATH'}) WHERE s.id = 105               CREATE (s)-[:BELONGS_TO]->(d);

// Student -> Course (ENROLLED_IN, with a grade property)
MATCH (s:Student {id:101}), (c:Course {code:'C1'}) CREATE (s)-[:ENROLLED_IN {grade:'A'}]->(c);
MATCH (s:Student {id:101}), (c:Course {code:'C3'}) CREATE (s)-[:ENROLLED_IN {grade:'B'}]->(c);
MATCH (s:Student {id:102}), (c:Course {code:'C1'}) CREATE (s)-[:ENROLLED_IN {grade:'A'}]->(c);
MATCH (s:Student {id:103}), (c:Course {code:'C2'}) CREATE (s)-[:ENROLLED_IN {grade:'B'}]->(c);
MATCH (s:Student {id:104}), (c:Course {code:'C2'}) CREATE (s)-[:ENROLLED_IN {grade:'A'}]->(c);
MATCH (s:Student {id:104}), (c:Course {code:'C3'}) CREATE (s)-[:ENROLLED_IN {grade:'A'}]->(c);
MATCH (s:Student {id:105}), (c:Course {code:'C4'}) CREATE (s)-[:ENROLLED_IN {grade:'C'}]->(c);

// ---- Visualise the whole graph (use Neo4j Browser; take a screenshot) ----
MATCH p = (n)-[r]->(m) RETURN p;

// ---- Some queries ----
MATCH (s:Student)-[:BELONGS_TO]->(d:Department {code:'CS'}) RETURN s.name AS cs_students;
MATCH (s:Student)-[e:ENROLLED_IN]->(c:Course) RETURN s.name AS student, c.title AS course, e.grade AS grade;
MATCH (d:Department)-[:OFFERS]->(c:Course)<-[:ENROLLED_IN]-(s:Student)
RETURN d.name AS department, c.title AS course, count(s) AS students ORDER BY students DESC;

// Count nodes and relationships by type
MATCH (n) RETURN labels(n)[0] AS label, count(*) AS total;
MATCH ()-[r]->() RETURN type(r) AS relationship, count(*) AS total;
