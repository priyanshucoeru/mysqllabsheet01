# Q11 – Install & configure Neo4j

## Docker (recommended)
```bash
docker run -d --name neo4j -p 7474:7474 -p 7687:7687 \
  -e NEO4J_AUTH=neo4j/password123 neo4j:5
```
- Neo4j Browser: http://localhost:7474  (user `neo4j`, password `password123`)
- Bolt (drivers): `bolt://localhost:7687`

## Native (Linux)
```bash
sudo apt install -y openjdk-17-jre-headless
# add the Neo4j apt repository (see https://neo4j.com/docs/operations-manual/current/installation/linux/debian/)
sudo apt install neo4j
sudo systemctl start neo4j
cypher-shell -u neo4j -p neo4j        # change the default password on first login
```

## Run the script
```bash
docker exec -i neo4j cypher-shell -u neo4j -p password123 < university.cypher
```
or paste the statements into Neo4j Browser.
