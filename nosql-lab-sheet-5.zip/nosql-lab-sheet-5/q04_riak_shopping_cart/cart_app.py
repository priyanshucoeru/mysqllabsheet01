"""Shopping cart in Riak KV.  Run:  python3 cart_app.py
Bucket 'carts', key = user id, value = whole cart as one JSON document."""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "riak_common"))
import riak_http as riak

BUCKET = "carts"


def get_cart(user):
    r = riak.get(BUCKET, user)
    if r["status"] == 200:
        return r["value"], r["vclock"]
    return {"user_id": user, "items": [], "total": 0}, None


def save_cart(user, cart, vclock):
    cart["total"] = sum(i["qty"] * i["price"] for i in cart["items"])
    return riak.put(BUCKET, user, cart, vclock=vclock)


def add_product(user, product_id, qty, price):
    cart, vc = get_cart(user)
    for item in cart["items"]:
        if item["product_id"] == product_id:       # already in cart -> increase quantity
            item["qty"] += qty
            break
    else:
        cart["items"].append({"product_id": product_id, "qty": qty, "price": price})
    save_cart(user, cart, vc)


def update_quantity(user, product_id, qty):
    cart, vc = get_cart(user)
    for item in cart["items"]:
        if item["product_id"] == product_id:
            item["qty"] = qty
    save_cart(user, cart, vc)


def remove_product(user, product_id):
    cart, vc = get_cart(user)
    cart["items"] = [i for i in cart["items"] if i["product_id"] != product_id]
    save_cart(user, cart, vc)


if __name__ == "__main__":
    user = "U1"
    riak.delete(BUCKET, user)

    riak.title("1. Add products")
    add_product(user, "P101", 1, 1500)
    add_product(user, "P102", 2, 500)
    add_product(user, "P103", 1, 1200)
    print(get_cart(user)[0])

    riak.title("2. Update quantity of P102 to 4")
    update_quantity(user, "P102", 4)
    print(get_cart(user)[0])

    riak.title("3. Retrieve the cart")
    cart = get_cart(user)[0]
    for i in cart["items"]:
        print(f"  {i['product_id']}  qty={i['qty']}  price={i['price']}  subtotal={i['qty'] * i['price']}")
    print("  CART TOTAL =", cart["total"])

    riak.title("4. Remove product P101")
    remove_product(user, "P101")
    print(get_cart(user)[0])

    riak.title("5. Empty the cart (delete key)")
    print("HTTP", riak.delete(BUCKET, user), "-> now:", riak.get(BUCKET, user)["status"], "(404 = gone)")
