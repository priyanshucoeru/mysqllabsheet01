// E-commerce graph: Customer, Product, Category, Order
MATCH (n) DETACH DELETE n;

CREATE (c1:Customer {id:1, name:'Amit Sharma', city:'Roorkee'}),
       (c2:Customer {id:2, name:'Priya Singh', city:'Delhi'}),
       (c3:Customer {id:3, name:'Rahul Verma', city:'Dehradun'}),

       (cat1:Category {name:'Electronics'}),
       (cat2:Category {name:'Accessories'}),
       (cat3:Category {name:'Books'}),

       (p1:Product {id:101, name:'Laptop',     price:55000}),
       (p2:Product {id:102, name:'Mouse',      price:500}),
       (p3:Product {id:103, name:'Headphones', price:2500}),
       (p4:Product {id:104, name:'Keyboard',   price:1200}),
       (p5:Product {id:105, name:'NoSQL Book', price:700}),

       (p1)-[:IN_CATEGORY]->(cat1),
       (p3)-[:IN_CATEGORY]->(cat1),
       (p2)-[:IN_CATEGORY]->(cat2),
       (p4)-[:IN_CATEGORY]->(cat2),
       (p5)-[:IN_CATEGORY]->(cat3),

       (o1:Order {id:1001, date:date('2026-09-01')}),
       (o2:Order {id:1002, date:date('2026-09-15')}),
       (o3:Order {id:1003, date:date('2026-10-02')}),
       (o4:Order {id:1004, date:date('2026-10-10')}),

       (c1)-[:PLACED]->(o1), (c1)-[:PLACED]->(o3),
       (c2)-[:PLACED]->(o2),
       (c3)-[:PLACED]->(o4),

       (o1)-[:CONTAINS {qty:1}]->(p1),
       (o1)-[:CONTAINS {qty:2}]->(p2),
       (o2)-[:CONTAINS {qty:1}]->(p3),
       (o2)-[:CONTAINS {qty:1}]->(p2),
       (o3)-[:CONTAINS {qty:1}]->(p5),
       (o4)-[:CONTAINS {qty:1}]->(p3),
       (o4)-[:CONTAINS {qty:1}]->(p4);

// Whole graph
MATCH p = (n)-[r]->(m) RETURN p;

// 1. Products purchased by customer Amit
MATCH (:Customer {name:'Amit Sharma'})-[:PLACED]->(:Order)-[:CONTAINS]->(p:Product)
RETURN DISTINCT p.name AS product, p.price AS price;

// 2. Same, with order, date and quantity
MATCH (:Customer {name:'Amit Sharma'})-[:PLACED]->(o:Order)-[c:CONTAINS]->(p:Product)
RETURN o.id AS order_id, o.date AS date, p.name AS product, c.qty AS qty ORDER BY o.date;

// 3. Total spent by each customer
MATCH (c:Customer)-[:PLACED]->(:Order)-[x:CONTAINS]->(p:Product)
RETURN c.name AS customer, sum(x.qty * p.price) AS total_spent ORDER BY total_spent DESC;

// 4. Order totals
MATCH (o:Order)-[x:CONTAINS]->(p:Product)
RETURN o.id AS order_id, sum(x.qty * p.price) AS order_total ORDER BY order_id;

// 5. Categories bought by Priya
MATCH (:Customer {name:'Priya Singh'})-[:PLACED]->(:Order)-[:CONTAINS]->(:Product)-[:IN_CATEGORY]->(cat:Category)
RETURN DISTINCT cat.name AS category;

// 6. Customers who bought Headphones
MATCH (c:Customer)-[:PLACED]->(:Order)-[:CONTAINS]->(:Product {name:'Headphones'}) RETURN c.name;

// 7. Recommendation: customers who bought what Amit bought also bought ...
MATCH (a:Customer {name:'Amit Sharma'})-[:PLACED]->(:Order)-[:CONTAINS]->(p:Product)<-[:CONTAINS]-(:Order)<-[:PLACED]-(other:Customer),
      (other)-[:PLACED]->(:Order)-[:CONTAINS]->(rec:Product)
WHERE other <> a AND NOT (a)-[:PLACED]->(:Order)-[:CONTAINS]->(rec)
RETURN rec.name AS recommended, count(DISTINCT other) AS score ORDER BY score DESC;

// 8. Best-selling products
MATCH (:Order)-[x:CONTAINS]->(p:Product) RETURN p.name AS product, sum(x.qty) AS units_sold ORDER BY units_sold DESC;
