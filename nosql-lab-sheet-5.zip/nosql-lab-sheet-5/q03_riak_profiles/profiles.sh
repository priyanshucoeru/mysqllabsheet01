#!/bin/bash
# Bucket "user_profiles": key = user id, value = profile + preferences as JSON
RIAK=${RIAK_URL:-http://localhost:8098}
B="$RIAK/buckets/user_profiles/keys"
JSON="Content-Type: application/json"

echo "== PUT profiles =="
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $B/U1 -d '{
  "name":"Amit Sharma","email":"amit@mail.com","city":"Roorkee",
  "preferences":{"language":"English","theme":"dark",
                 "notifications":{"email":true,"sms":false,"push":true}}}'
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $B/U2 -d '{
  "name":"Priya Singh","email":"priya@mail.com","city":"Delhi",
  "preferences":{"language":"Hindi","theme":"light",
                 "notifications":{"email":true,"sms":true,"push":false}}}'
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $B/U3 -d '{
  "name":"Rahul Verma","email":"rahul@mail.com","city":"Dehradun",
  "preferences":{"language":"English","theme":"light",
                 "notifications":{"email":false,"sms":false,"push":true}}}'

echo; echo "== GET profile of U1 =="
curl -s $B/U1; echo

echo; echo "== GET U2 (show response headers: content type, ETag, vector clock) =="
curl -si $B/U2 | head -15; echo

echo; echo "== PUT (update) - change U1 theme to light and language to Hindi =="
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $B/U1 -d '{
  "name":"Amit Sharma","email":"amit@mail.com","city":"Roorkee",
  "preferences":{"language":"Hindi","theme":"light",
                 "notifications":{"email":true,"sms":false,"push":true}}}'
curl -s $B/U1; echo
echo; echo "(Riak stores the value as an opaque blob: to change one field, GET the whole JSON, edit it, PUT it back.)"
