#!/bin/bash
# Bucket "user_sessions":  key = session id,  value = JSON session information
RIAK=${RIAK_URL:-http://localhost:8098}
B="$RIAK/buckets/user_sessions/keys"
JSON="Content-Type: application/json"
NOW=$(date -u +%Y-%m-%dT%H:%M:%SZ)

echo "== Store sessions =="
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $B/sess-1001 \
  -d "{\"session_id\":\"sess-1001\",\"user_id\":\"U1\",\"login_time\":\"$NOW\",\"status\":\"active\"}"
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $B/sess-1002 \
  -d "{\"session_id\":\"sess-1002\",\"user_id\":\"U2\",\"login_time\":\"$NOW\",\"status\":\"active\"}"
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $B/sess-1003 \
  -d "{\"session_id\":\"sess-1003\",\"user_id\":\"U3\",\"login_time\":\"$NOW\",\"status\":\"expired\"}"

echo; echo "== Retrieve session information using its key =="
curl -s $B/sess-1001; echo

echo; echo "== User logs out -> update status =="
curl -s -X PUT -H "$JSON" -w "HTTP %{http_code}\n" $B/sess-1001 \
  -d "{\"session_id\":\"sess-1001\",\"user_id\":\"U1\",\"login_time\":\"$NOW\",\"logout_time\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"status\":\"closed\"}"
curl -s $B/sess-1001; echo

echo; echo "== Delete an expired session =="
curl -s -X DELETE -w "HTTP %{http_code}\n" $B/sess-1003
curl -s -w "  <- HTTP %{http_code}\n" $B/sess-1003

echo; echo "== Session ids in bucket =="
curl -s "$RIAK/buckets/user_sessions/keys?keys=true"; echo
