// Social network: Person, Company; FRIENDS_WITH, FOLLOWS, WORKS_AT
MATCH (n) DETACH DELETE n;

CREATE (amit:Person  {name:'Amit',  city:'Roorkee',  age:21}),
       (priya:Person {name:'Priya', city:'Delhi',     age:24}),
       (rahul:Person {name:'Rahul', city:'Dehradun',  age:30}),
       (neha:Person  {name:'Neha',  city:'Roorkee',   age:22}),
       (karan:Person {name:'Karan', city:'Delhi',     age:35}),
       (sana:Person  {name:'Sana',  city:'Mumbai',    age:28}),
       (tcs:Company  {name:'TCS'}),
       (infosys:Company {name:'Infosys'}),
       (google:Company  {name:'Google'}),

       // friendships (stored once, queried in both directions)
       (amit)-[:FRIENDS_WITH {since:2020}]->(priya),
       (amit)-[:FRIENDS_WITH {since:2021}]->(rahul),
       (priya)-[:FRIENDS_WITH {since:2019}]->(neha),
       (rahul)-[:FRIENDS_WITH {since:2022}]->(karan),
       (neha)-[:FRIENDS_WITH {since:2023}]->(amit),

       // follows (directed)
       (amit)-[:FOLLOWS]->(karan),
       (priya)-[:FOLLOWS]->(karan),
       (rahul)-[:FOLLOWS]->(karan),
       (neha)-[:FOLLOWS]->(sana),
       (karan)-[:FOLLOWS]->(sana),
       (sana)-[:FOLLOWS]->(amit),

       // workplaces
       (amit)-[:WORKS_AT {role:'Intern'}]->(tcs),
       (rahul)-[:WORKS_AT {role:'Developer'}]->(tcs),
       (priya)-[:WORKS_AT {role:'Analyst'}]->(infosys),
       (karan)-[:WORKS_AT {role:'Manager'}]->(google),
       (sana)-[:WORKS_AT {role:'Engineer'}]->(google);

// Whole graph
MATCH p = (n)-[r]->(m) RETURN p;

// 1. Friends of Amit  (direction ignored: friendship goes both ways)
MATCH (:Person {name:'Amit'})-[:FRIENDS_WITH]-(f:Person) RETURN f.name AS friend;

// 2. Followers of Karan (who follows Karan)
MATCH (f:Person)-[:FOLLOWS]->(:Person {name:'Karan'}) RETURN f.name AS follower;

// 3. People that Amit follows
MATCH (:Person {name:'Amit'})-[:FOLLOWS]->(p:Person) RETURN p.name AS following;

// 4. Number of followers of each person
MATCH (p:Person) OPTIONAL MATCH (f:Person)-[:FOLLOWS]->(p)
RETURN p.name AS person, count(f) AS followers ORDER BY followers DESC;

// 5. Friends of friends (suggestions): not already friends, not himself
MATCH (a:Person {name:'Amit'})-[:FRIENDS_WITH]-(:Person)-[:FRIENDS_WITH]-(fof:Person)
WHERE fof <> a AND NOT (a)-[:FRIENDS_WITH]-(fof)
RETURN DISTINCT fof.name AS suggested_friend;

// 6. Mutual friends of Amit and Priya
MATCH (:Person {name:'Amit'})-[:FRIENDS_WITH]-(m:Person)-[:FRIENDS_WITH]-(:Person {name:'Priya'})
RETURN m.name AS mutual_friend;

// 7. Colleagues of Amit (same company)
MATCH (:Person {name:'Amit'})-[:WORKS_AT]->(c:Company)<-[:WORKS_AT]-(col:Person)
RETURN c.name AS company, col.name AS colleague;

// 8. Friends who live in the same city
MATCH (a:Person)-[:FRIENDS_WITH]-(b:Person) WHERE a.city = b.city AND id(a) < id(b)
RETURN a.name, b.name, a.city;

// 9. Shortest path between Amit and Karan
MATCH p = shortestPath((:Person {name:'Amit'})-[:FRIENDS_WITH|FOLLOWS*..6]-(:Person {name:'Karan'}))
RETURN [n IN nodes(p) | n.name] AS path, length(p) AS hops;
