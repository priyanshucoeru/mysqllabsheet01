"""Explicit transactions with the Neo4j Python driver.
Setup: pip install neo4j      Run: python3 transactions_python.py"""
import os
from neo4j import GraphDatabase

URI = os.environ.get("NEO4J_URI", "bolt://localhost:7687")
AUTH = (os.environ.get("NEO4J_USER", "neo4j"), os.environ.get("NEO4J_PASSWORD", "password123"))
driver = GraphDatabase.driver(URI, auth=AUTH)


def balances(session):
    return [(r["id"], r["balance"]) for r in session.run("MATCH (a:Account) RETURN a.id AS id, a.balance AS balance ORDER BY id")]


with driver.session() as session:
    session.run("MATCH (n) DETACH DELETE n")
    session.run("CREATE CONSTRAINT account_id IF NOT EXISTS FOR (a:Account) REQUIRE a.id IS UNIQUE")
    session.run("CREATE (:Account {id:1, balance:1000}), (:Account {id:2, balance:500})")
    print("Start      :", balances(session))

    # ---- 1. successful transaction (commit) ----
    with session.begin_transaction() as tx:
        tx.run("MATCH (a:Account {id:1}) SET a.balance = a.balance - 200")
        tx.run("MATCH (b:Account {id:2}) SET b.balance = b.balance + 200")
        tx.commit()
    print("After commit  :", balances(session))

    # ---- 2. failing transaction -> automatic rollback ----
    try:
        with session.begin_transaction() as tx:
            tx.run("MATCH (a:Account {id:1}) SET a.balance = a.balance - 500")
            tx.run("CREATE (:Account {id:2, balance:0})")      # duplicate id -> constraint error
            tx.commit()
    except Exception as e:
        print("Transaction failed ->", type(e).__name__, "- rolled back")
    print("After failure :", balances(session))               # unchanged by the failed transaction

    # ---- 3. explicit rollback ----
    tx = session.begin_transaction()
    tx.run("MATCH (a:Account {id:1}) SET a.balance = 0")
    print("Inside tx     :", [(r["id"], r["balance"]) for r in tx.run("MATCH (a:Account) RETURN a.id AS id, a.balance AS balance ORDER BY id")])
    tx.rollback()
    print("After rollback:", balances(session))

driver.close()
