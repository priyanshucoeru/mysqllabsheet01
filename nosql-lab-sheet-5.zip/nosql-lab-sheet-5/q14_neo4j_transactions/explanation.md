# Transactions, consistency and availability in Neo4j

## Transactions (ACID)
Neo4j is a **fully ACID** graph database. All reads/writes happen inside a transaction (auto-commit for single statements, explicit with `:begin … :commit/:rollback` or `session.begin_transaction()`).

| Property | How Neo4j provides it (seen in the demo) |
|---|---|
| **Atomicity** | A transaction's CREATE/SET/DELETE all succeed or none do – transaction 2 (rollback) and 3 (constraint failure) leave data unchanged. |
| **Consistency** | Constraints (`UNIQUE`, existence), and the rule that a relationship must connect two existing nodes (`DELETE` a node needs `DETACH DELETE`) keep the graph valid. |
| **Isolation** | Default **read-committed**: other sessions don't see uncommitted changes. Write locks on touched nodes/relationships prevent lost updates; deadlocks are detected. |
| **Durability** | Changes are written to the **transaction log (write-ahead log)** and flushed before commit returns; recovered after a crash. |

## Consistency & availability in a cluster
- **Single instance:** transactions are ACID on that server.
- **Cluster (Enterprise / Aura):** *primary* servers form **Raft** consensus groups – a write commits only after a **majority** of primaries have it (strong consistency). *Secondary* servers replicate asynchronously for scalable reads (may lag slightly; use bookmarks for causal consistency).
- **Availability:** if a primary fails, the remaining majority elects a new leader automatically; reads continue on other members.
- In CAP terms: Neo4j favours **consistency (CP)** within the primary cluster, with high availability while a majority is up.
