// Run with cypher-shell (supports :begin / :commit / :rollback):
//   docker exec -i neo4j cypher-shell -u neo4j -p password123 < transactions.cypher
MATCH (n) DETACH DELETE n;
CREATE CONSTRAINT account_id IF NOT EXISTS FOR (a:Account) REQUIRE a.id IS UNIQUE;   // consistency rule

// ======= TRANSACTION 1 : COMMIT (several CREATE / MATCH / SET / DELETE together) =======
:begin
CREATE (:Account {id:1, owner:'Amit',  balance:1000});
CREATE (:Account {id:2, owner:'Priya', balance:500});
CREATE (:Account {id:3, owner:'Temp',  balance:0});
MATCH (a:Account {id:1}), (b:Account {id:2}) CREATE (a)-[:KNOWS {since:2024}]->(b);
// money transfer of 200 from account 1 to account 2
MATCH (a:Account {id:1}) SET a.balance = a.balance - 200;
MATCH (b:Account {id:2}) SET b.balance = b.balance + 200;
// delete the temporary node
MATCH (t:Account {id:3}) DETACH DELETE t;
:commit

MATCH (a:Account) RETURN a.id, a.owner, a.balance ORDER BY a.id;     // 800 / 700, Temp is gone

// ======= TRANSACTION 2 : ROLLBACK (nothing is applied) =======
:begin
MATCH (a:Account {id:1}) SET a.balance = a.balance - 500;
CREATE (:Account {id:99, owner:'Ghost', balance:9999});
MATCH (a:Account) RETURN a.id, a.balance ORDER BY a.id;              // inside tx: sees its own changes
:rollback

MATCH (a:Account) RETURN a.id, a.owner, a.balance ORDER BY a.id;     // unchanged: 800 / 700, no Ghost

// ======= TRANSACTION 3 : FAILS because of the constraint -> whole tx is rolled back =======
:begin
MATCH (a:Account {id:1}) SET a.balance = a.balance + 100;
CREATE (:Account {id:2, owner:'Duplicate', balance:1});              // violates UNIQUE(id) -> error
:commit
:rollback

MATCH (a:Account) RETURN a.id, a.owner, a.balance ORDER BY a.id;     // still 800 / 700 (the +100 was undone too)
